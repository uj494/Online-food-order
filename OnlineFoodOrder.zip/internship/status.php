<?php
session_start();
error_reporting(0);
require_once("modal/menumodel.php");
require_once("modal/cartmodel.php");
require_once("modal/ordermodel.php");
$obj = new ordermodel();
$id = $_REQUEST['edit'];
$status = $_REQUEST['status'];

if ($status == "Pending"){
	$status = "Delivered";
	$obj->update_status($id, $status);
	echo $status;
} 
?>