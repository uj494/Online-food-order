<?php
session_start();
error_reporting(0);
require_once("modal/ordermodel.php");

$obj = new ordermodel();

if(!empty($_REQUEST['id'])){
	$id = $_REQUEST['id'];
	$obj->delete_card($id);
}

if(!empty($_REQUEST['idadd'])){
	$idadd = $_REQUEST['idadd'];
	$obj->delete_add($idadd);
}
?>