<?php
error_reporting(0);
require_once("modal/msgmodel.php");

$obj = new msgmodel();
$id = "Not a customer";
$name = $_POST['name'];
$phone = $_POST['phone'];
$email = $_POST['email'];
$msg = $_POST['msg'];

$obj->insert_msg($id, $name, $phone, $email, $msg);
header("location: index_contact.php?contact=success");
?>