<?php
session_start();
error_reporting(0);
require_once("modal/menumodel.php");
require_once("modal/cartmodel.php");
require_once("modal/ordermodel.php");
$obj = new menumodel();
$objcart = new cartmodel();
$objorder = new ordermodel();
$id = $_SESSION['id'];
$cart = $objcart->fetch_cartByCustId($id);
//var_dump($cart);
echo $name = $_POST['full_name'];
echo $street1 = $_POST['street1'];
echo $street2 = $_POST['street2'];
echo $city = $_POST['city'];
echo $phone = $_POST['phone'];
echo $zip = $_POST['zip'];
echo $date = date("y/m/d");
echo $status = "Pending";
echo $h = $_POST['form'];
if(is_numeric($_POST['form'])){
	$paymode = "Credit/Debit Card";
	$card = $_POST['form'];
}else{
	$paymode = $_POST['form'];
	if(!empty($_POST['card']))
	$card = $_POST['card'];
	else $card = "Not paid by card";
}
echo $card;
foreach ($cart as $key) {
	$category = $key->category;
	$itemid = $key->item_id;
	echo $quant2 = $key->quant;
	$menu = $obj->fetch_menuById($category, $itemid);
	$item_name = $menu->name;
	$quant = $menu->quantity;
	$img = $menu->images;
	$cost = $key->rs;
	echo $menu->name."<br>".$menu->quantity."<br>".$menu->images;
	$objorder->insert_order($id, $item_name, $quant, $quant2, $img, $cost, $name, $phone, $street1, $street2, $city, $zip, $date, $paymode, $status, $card); 
	
}
if (isset($_POST['saved'])) {
	$crd = $objorder->fetch_card($id, $card);
	if (empty($crd)) {
		$objorder->insert_card($id, $card);
	}
	
}
//exit;
$objcart->delete_cartByCustId($id);
header("location: your_orders.php?order=success");

?>