<?php
session_start();
error_reporting(0);
require_once("modal/usersmodel.php");;
$obj = new usersmodel();
$id = $_SESSION['id'];
$pass = $_REQUEST['new'];
$confirm_pass = $_REQUEST['conf'];
$current_pass = $_REQUEST['crr'];
$actual_pass = $_REQUEST['act'];
$button = $_REQUEST['button'];
$fname = $_POST['fname'];
$lname = $_POST['lname'];


if(isset($_POST['profile'])){
	$obj->update_profile($id, $fname, $lname);
	header("location: useraccount.php?pro=changed");
}

if($button == "update"){
	if($pass == $confirm_pass){
		if($current_pass == $actual_pass){
			$obj->update_pass($id, $pass);
			echo "updated";
			exit();
			//header("location:login.php?msg=$msg");
		}else{
			echo "invalid";
			exit;
		}
	}else{
		echo "notmatch";
		exit;
	}
}
?>