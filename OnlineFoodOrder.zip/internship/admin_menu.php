<!--A Design by W3layouts 
Author: W3layout
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<?php
session_start();
error_reporting(0);
if(!isset($_SESSION['id'])){
	header("location: index.php");
}
require_once("modal/menumodel.php");

$obj = new menumodel();

?>
<!DOCTYPE html>
<html>
<head>
<title>My Hotel</title>
<link href="web/css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="web/js/jquery.min.js"></script>
<!-- Custom Theme files -->
<!--theme-style-->
<link href="web/css/style.css" rel="stylesheet" type="text/css" media="all" />	
<!--//theme-style-->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Cookery Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!---->
<link href='//fonts.googleapis.com/css?family=Raleway:400,200,100,300,500,600,700,800,900' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Open+Sans+Condensed:300,300italic,700' rel='stylesheet' type='text/css'>
<!-- start-smoth-scrolling -->
		<script type="text/javascript" src="web/js/move-top.js"></script>
		<script type="text/javascript" src="web/js/easing.js"></script>
		<script type="text/javascript">
			jQuery(document).ready(function($) {
				$(".scroll").click(function(event){		
					event.preventDefault();
					$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
				});
			});
		</script>
	<!-- start-smoth-scrolling -->
<link href="web/css/styles.css" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="web/css/component.css" />
	<!-- animation-effect -->
<link href="web/css/animate.min.css" rel="stylesheet">

<script src="web/js/wow.min.js"></script>
<script>
 new WOW().init();
</script>
<script src="web/js/sweetalert-dev.js"></script>
<link rel="stylesheet" href="web/css/sweetalert.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<!-- //animation-effect -->

</head>
<body>
<div class="header head">
	<div class="container">
		<div class="logo animated wow pulse" data-wow-duration="1000ms" data-wow-delay="500ms">
			<h1><a href="index.php"><span>My Hotel</span></a></h1>
		</div>
		<div class="nav-icon">		
			<a href="#" class="navicon"></a>
				<div class="toggle">
					<ul class="toggle-menu">
						<li><a  href="admin_index.php">Home</a></li>
						<li><a  class="active" href="admin_menu.php">Menu</a></li>
						<li><a  href="addfood.php">Add Items</a></li>
						<li><a  href="admin_orders.php">All orders</a></li>
						<li><a  href="bookings.php">All bookings</a></li>
						<li><a  href="cust_msg.php">Customer messages</a></li>
						<li><a  href="useraccount.php">Your Account</a></li>
						<li><a  href="logout.php">Logout</a></li>
					</ul>
				</div>
			<script>
			$('.navicon').on('click', function (e) {
			  e.preventDefault();
			  $(this).toggleClass('navicon--active');
			  $('.toggle').toggleClass('toggle--active');
			});
			</script>
		</div>
	<div class="clearfix"></div>
	</div>
	<!-- start search-->	
		
</div>
<!--content-->
<?php
		if(!empty($_REQUEST['rem'])){	
			
	?>
<div align="center" class="alert alert-success"   id="msg">
  <i class="fa fa-check-circle" style="font-size:48px; margin-bottom: 3px; margin-top: -10px;"></i><h3><strong>Item removed successfully from the menu!</strong></h3>
</div>
<?php } ?>
	<div class="menu">
		<div class="container">
			<div class="menu-top">
				<div class="col-md-4 menu-left animated wow fadeInLeft" data-wow-duration="1000ms" data-wow-delay="500ms">
					<h3>Menu</h3>
					<label><i class="glyphicon glyphicon-menu-up"></i></label>
					<span>Breakfast</span>
				</div>
				<div class="col-md-8 menu-right animated wow fadeInRight" data-wow-duration="1000ms" data-wow-delay="500ms">
					<p></p>
				</div>
				<div class="clearfix"> </div>
			</div>
			<div class="menu-bottom animated wow fadeInUp" data-wow-duration="1000ms" data-wow-delay="500ms">
				<?php
								$breakfast = $obj->fetch_menu('breakfast');
 								
 								//$num_rows = mysqli_fetch_assoc($result);              
 								  foreach ($breakfast as $row){ 
 									
								?>
				<div class="col-md-4 menu-bottom1">
					<div class="btm-right thumbnail">
						<a href="events.html"><?php
							echo"<img src='web/uploads/".$row->images."' alt='' class='' style='display:block; max-width:100%; height: 300px;'>" ?>
							<div class="captn">
								
								<h4><?php echo $row->name ?></h4>
								<p>₹<?php echo $row->cost ?></p>
								<p><?php echo $row->quantity ?></p>			
							</div>
						</a>										
					</div>
				<div align="center" style="padding-bottom:20px;">
					
						<a><button class="btn btn-primary" onclick="JSalert('<?=$row->id?>','breakfast')">Remove</button></a>
					
				</div>
			</div>

			<?php }?>
		</div>
	</div>
		<br>
			<div class="container">
			<div class="menu-top">
				<div class="col-md-3 menu-left animated wow fadeInLeft" data-wow-duration="1000ms" data-wow-delay="500ms">
					<label><i class="glyphicon glyphicon-menu-up"></i></label>
					<span>Sabzi and Daal</span>
				</div>
				<div class="clearfix"> </div>				
			</div>
			<div class="menu-bottom animated wow fadeInRight" data-wow-duration="1000ms" data-wow-delay="500ms">
				<?php
								$sabzi = $obj->fetch_menu('sabzi');
 								
 								//$num_rows = mysqli_fetch_assoc($result);              
 								  foreach ($sabzi as $row){ 
 									
								?>
				<div class="col-md-4 menu-bottom1">
					<div class="btm-right thumbnail">
						<a href="events.html">
							<?php
							echo"<img src='web/uploads/".$row->images."' alt='' class='' style='display:block; max-width:100%; height: 300px;'>" ?>
							<div class="captn">
								<h4><?php echo $row->name ?></h4>
								<p>₹<?php echo $row->cost ?></p>
								<p><?php echo $row->quantity ?></p>				
							</div>
						</a>	
					</div>
				<div align="center" style="padding-bottom:20px;">
					<a><button class="btn btn-primary" onclick="JSalert('<?=$row->id?>','sabzi')">Remove</button></a>
				</div>
				</div>
				<?php }?>
			</div>
		</div>
				
				<br>
			<div class="container">
			<div class="menu-top">
				<div class="col-md-4 menu-left animated wow fadeInLeft" data-wow-duration="1000ms" data-wow-delay="500ms">
					<label><i class="glyphicon glyphicon-menu-up"></i></label>
					<span>Roti</span>
				</div>
				<div class="clearfix"> </div>				
			</div>
			<div class="menu-bottom animated wow fadeInDown" data-wow-duration="1000ms" data-wow-delay="500ms">
				<?php
								$roti = $obj->fetch_menu('roti');
 								
 								//$num_rows = mysqli_fetch_assoc($result);              
 								  foreach ($roti as $row){ 
 									
								?>
				<div class="col-md-4 menu-bottom1">
					<div class="btm-right thumbnail">
						<a href="events.html">
							<?php
							echo"<img src='web/uploads/".$row->images."' alt='' class='' style='display:block; max-width:100%; height: 300px;'>" ?>
							<div class="captn">
								<h4><?php echo $row->name ?></h4>
								<p>₹<?php echo $row->cost ?></p>
								<p><?php echo $row->quantity ?></p>				
							</div>
						</a>		
					</div>
				<div align="center" style="padding-bottom:20px;">
					<a><button class="btn btn-primary" onclick="JSalert('<?=$row->id?>','roti')">Remove</button></a>
				</div>
				</div>
				<?php }?>
			</div>
		</div>
				
				<div class="clearfix"> </div>				
			</div>
		</div>
	</div>

	<script type="text/javascript">
	function JSalert($link, $cat){
	swal({   title: "Your item will be removed from menu!",   
    text: "Are you sure to proceed?",   
    type: "warning",   
    showCancelButton: true,   
    confirmButtonColor: "#FF0000",   
    confirmButtonText: "Remove My Item!",   
    cancelButtonText: "No!",   
    closeOnConfirm: false,   
    closeOnCancel: true }, 
    function(isConfirm){   
        if (isConfirm) 
    {   
    	/*swal("Item Removed!", "Your item is removed permanently!", "success");*/
    		window.location.href = 'deleteitem.php?id='+$link+'&cat='+$cat;
           
        } 
         });
}
 


</script>
<!--footer-->
	<div class="footer">
		<div class="container">
			<div class="footer-head">
				<div class="col-md-8 footer-top animated wow fadeInRight" data-wow-duration="1000ms" data-wow-delay="500ms">
					<ul class=" in">
						<li><a class="active" href="admin_index.php">Home</a></li>
						<li><a  href="admin_menu.php">Menu</a></li>
						<li><a  href="addfood.php">Add Items</a></li>
						<li><a  href="admin_orders.php">All orders</a></li>
						<li><a  href="bookings.php">All bookings</a></li>
						<li><a  href="cust_msg.php">Customer messages</a></li>
						<li><a  href="useraccount.php">Your Account</a></li>
						<li><a  href="logout.php">Logout</a></li>
					</ul>					
						<span>There are many variations of passages</span>
				</div>
				<div class="col-md-4 footer-bottom  animated wow fadeInLeft" data-wow-duration="1000ms" data-wow-delay="500ms">
					<h2>Follow Us</h2>
					<label><i class="glyphicon glyphicon-menu-up"></i></label>
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis.</p>
					<ul class="social-ic">
						<li><a href="#"><i></i></a></li>
						<li><a href="#"><i class="ic"></i></a></li>
						<li><a href="#"><i class="ic1"></i></a></li>
						<li><a href="#"><i class="ic2"></i></a></li>
						<li><a href="#"><i class="ic3"></i></a></li>
					</ul>

				</div>
			<div class="clearfix"> </div>
					
			
	</div>		
	<!--//footer-->

</body>
</html>