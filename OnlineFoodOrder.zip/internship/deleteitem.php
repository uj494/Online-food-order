<?php
session_start();
error_reporting(0);
require_once("modal/menumodel.php");

$obj = new menumodel();

$id = $_REQUEST['id'];
$category = $_REQUEST['cat'];

$obj->delete_menu($category, $id);
header("location: admin_menu.php?rem=success")
?>