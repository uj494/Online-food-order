<?php
session_start();
error_reporting(0);
require_once("modal/custmodel.php");;
$obj = new custmodel();
$id = $_SESSION['id'];
$pass = $_REQUEST['new'];
$confirm_pass = $_REQUEST['conf'];
$current_pass = $_REQUEST['crr'];
$actual_pass = $_REQUEST['act'];
$button = $_REQUEST['button'];
$fname = $_POST['fname'];
$lname = $_POST['lname'];
$ename = $_POST['ename'];
$target = "uploads/".basename($_FILES['img']['name']);
$image = $_FILES['img']['name'];
$pro = $obj->fetch_userById($id);

if(isset($_POST['profile'])){
	$obj->update_custprofile($id, $fname, $lname, $ename);
	
	header("location: cust_account.php?pro=changed");
}

if(isset($_POST['profileimg'])){
	
	
	$obj->update_profileimg($image,$id);
	
	move_uploaded_file($_FILES['img']['tmp_name'], $target);
	header("location: cust_account.php?pro=changed");
}

if($button == "update"){
	if($pass == $confirm_pass){
		if($current_pass == $actual_pass){
			$obj->update_custpass($id, $pass);
			echo "updated";
			exit();
			//header("location:login.php?msg=$msg");
		}else{
			echo "invalid";
			exit;
		}
	}else{
		echo "notmatch";
		exit;
	}
}
?>