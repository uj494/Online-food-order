<?php
session_start();
//include 'C:\wamp64\www\internship\includes\dbh-inc.php';
require_once("modal/custmodel.php");

$obj = new custmodel();
$userid = $_POST['id'];
$password = $_POST['pwd'];


if (empty($userid)) {
	header('Location: cust_login.php?error=empty');	
}else{
	$recorduser = $obj->fetch_userUsername($userid);
	$row = $recorduser;
 	
	if (empty($row)) {
		header('Location: cust_login.php?error=username');
		
	}elseif ($row->password != $password) {

		header('Location: cust_login.php?error=pwd');	
	}else {
			$login = $obj->fetch_userUnamePass($userid, $password);
			$rowlogin = $login;
	   		$_SESSION['id'] = $rowlogin->id;
	   		
	   		header("Location: cust_index.php");
	   	}
	   
}
		
	