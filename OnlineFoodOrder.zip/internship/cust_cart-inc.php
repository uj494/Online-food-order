

<?php
session_start();
error_reporting(0);
require_once("modal/cartmodel.php");
require_once("modal/menumodel.php");

		$obj = new cartmodel();
		$objmenu = new menumodel();
		$id = $_SESSION['id'];
		$category = $_POST['cat'];
		$itemid = $_POST['itemid'];
		$row = $objmenu->fetch_menuById($category, $itemid);
		$rs = $row->cost;
		$cart = $obj->fetch_cartByCatItem($category, $itemid, $id);

		if(!empty($cart)){
			echo $cart->id;
			header('Location: cust_menu.php?cart=already');
		} else {
			$obj->insert_cart($category, $itemid, $id, $rs);
			header('Location: cust_menu.php?cart=success');
			}
		?>			
			
			

			
						
			

			
	