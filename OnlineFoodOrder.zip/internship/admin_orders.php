<?php
session_start();
error_reporting(0);
if(!isset($_SESSION['id'])){
	header("location: index.php");
}
require_once("modal/menumodel.php");
require_once("modal/cartmodel.php");
require_once("modal/ordermodel.php");

?>
<!DOCTYPE html>
<html>
<head>
<title>My Hotel</title>
<link href="web/css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="web/js/jquery.min.js"></script>
<!-- Custom Theme files -->
<!--theme-style-->
<link href="web/css/style.css" rel="stylesheet" type="text/css" media="all" />	
<!--//theme-style-->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Cookery Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!---->
<link href='//fonts.googleapis.com/css?family=Raleway:400,200,100,300,500,600,700,800,900' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Open+Sans+Condensed:300,300italic,700' rel='stylesheet' type='text/css'>
<!-- start-smoth-scrolling -->
		<script type="text/javascript" src="web/js/move-top.js"></script>
		<script type="text/javascript" src="web/js/easing.js"></script>
		<script type="text/javascript">
			jQuery(document).ready(function($) {
				$(".scroll").click(function(event){		
					event.preventDefault();
					$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
				});
			});
		</script>
	<!-- start-smoth-scrolling -->
<link href="web/css/styles.css" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="web/css/component.css" />
	<!-- animation-effect -->
<link href="web/css/animate.min.css" rel="stylesheet"> 
<script src="web/js/wow.min.js"></script>
<script>
 new WOW().init();
</script>
<style>/* Flaired edges, by Tomas Theunissen */

hr.style-one {
	border: 1px;
	height: 1px;
	
	background-image: linear-gradient(to right, #ccc, #333, #ccc); 
}

hr.style-seven {
    overflow: visible; /* For IE */
    height: 30px;
    width: 280px;
    border-style: solid;
    border-color: black;
    border-width: 1px 0 0 0;
    border-radius: 20px;
}
hr.style-seven:before { /* Not really supposed to work, but does */
    display: block;
    content: "";
    height: 30px;
    margin-top: -31px;
    border-style: solid;
    border-color: black;
    border-width: 0 0 1px 0;
    border-radius: 20px;
}

.floatLeft {
	width: 50%;
	float: left;
	margin-left: -80px;
}

.floatRight {
	width: 50%;
	float: right;
	margin-top: 35px;
}
</style>
<!-- //animation-effect -->

</head>
<body>
<div class="header head">
	<div class="container">
		<div class="logo animated wow pulse" data-wow-duration="1000ms" data-wow-delay="500ms">
			<h1><a href="index.php"><span>My Hotel</span></a></h1>
		</div>
		<div class="nav-icon">		
			<a href="#" class="navicon"></a>
				<div class="toggle">
					<ul class="toggle-menu">
						<li><a  href="admin_index.php">Home</a></li>
						<li><a  href="admin_menu.php">Menu</a></li>
						<li><a  href="addfood.php">Add Items</a></li>
						<li><a  class="active" href="admin_orders.php">All orders</a></li>
						<li><a  href="bookings.php">All bookings</a></li>
						<li><a  href="cust_msg.php">Customer messages</a></li>
						<li><a  href="useraccount.php">Your Account</a></li>
						<li><a  href="logout.php">Logout</a></li>
					</ul>
				</div>
			<script>
			$('.navicon').on('click', function (e) {
			  e.preventDefault();
			  $(this).toggleClass('navicon--active');
			  $('.toggle').toggleClass('toggle--active');
			});
			</script>
		</div>
	<div class="clearfix"></div>
	</div>
	<!-- start search-->	
		
</div><br>

	
		<div class="logo animated wow pulse" style="margin-top: -7px; margin-left: 20px;">
			<h1>Your Orders</h1>
			<hr class="style-seven">
		</div><br><div class="clearfix"> </div>


<style type="text/css">
	td {
		padding-top: 20px;
		padding-right: 70px;
		padding-bottom: 20px;
	}

	th {
		padding-top: 10px;
		padding-right: 70px;
	}
	tr.bordered {
    border-bottom: 1px solid ;
   }
</style>
	
<?php
//echo $_SESSION['id'];
$objmenu = new menumodel();
$obj = new cartmodel();
$objorder = new ordermodel();
$id = $_SESSION['id'];
$row = $objorder->fetch_orderDesc();

if(!empty($row)){
	echo "<div style='padding-left:10px;'>";
				echo "<table><tr>
						<td></td>
						<th><h4><strong>Order details</strong></h4></th>
						<th><h4><strong>Customer</strong></h4></th>
						<th><h4><strong>Address</strong></h4></th>
						<th><h4><strong>Quantity</strong></h4></th>
						<th><h4><strong>Mode of payment</strong></h4></th>
						<th><h4><strong>Date of order</strong></h4></th>
						<th><h4><strong>Status</strong></h4></th>
						</tr>";
	foreach ($row as $order){
				
				echo"<tr>
					<td rowspan='2'>
						<div class='col-md-10 menu-bottom1'>
							<div>
								<img src='web/uploads/".$order->img."' alt='' class= 'img-rounded' style='width:100px; height: 100px;'>
							</div>
						</div>
					</td>";
					if($order->quantity2==1){
					  		$p = "Package";
					  	} else {
					  		$p = "Packages";
					  	}
				echo "<th><h4>".$order->item_name."</h4></th>
						<td>".$order->receiver."</td>
						<td>".$order->address."</td>
						<td>".$order->quantity2." ".$p."</td>
						<td>".$order->pay."</td>
						<td>".$order->date1."</td>
						<td id='status".$order->id."'>".$order->status."</td>
						<td></td><td><p align='center'><h2>₹".$order->cost."</h2></p></td>
						</tr>";
						
				echo "<tr class='bordered' id='pad'>";
				echo "<td><h5>".$order->quantity."</h5></td>
					  <td>".$order->phone."</td>
					  <td>".$order->address2."</td>
					  <td colspan='6'><p align='right'>";
					  if($order->status == "Pending"){
						echo "<button class='btn' id='".$order->id."'>Delivered</button>";
						}
				echo "</p>
					</td>
					</tr>";
				
			}
		

	echo "</table></div><br>";

} else{
	echo "<div style='padding-left:20px;'>
		 <h2>No orders till now.</h2>
		 </div>";
}
?>
	<div style="text-align: center;">
		<a href="admin_menu.php" style="background-color: blue; color: white; display: inline-block; padding: 10px 30px; border-radius: 8px;">Proceed to menu</a>
	</div>
<br><br>

<script type="text/javascript">
	$(function(){
		$(".btn").click(function(){
			var id = $(this).attr("id");
			var sta = $("#status"+id).html();
			//alert(sta);
			//$.post("status.php?edit="+id+"&status="+sta);
			$.post("status.php?edit="+id+"&status="+sta,function(data){
				//alert(data);
				$("#status"+id).html(data);
				jQuery("#"+id).hide();
			});
		});
	});
</script>
<!--footer-->
	<div class="footer">
		<div class="container">
			<div class="footer-head">
				<div class="col-md-8 footer-top animated wow fadeInRight" data-wow-duration="1000ms" data-wow-delay="500ms">
					<ul class=" in">
						<li><a class="active" href="admin_index.php">Home</a></li>
						<li><a  href="admin_menu.php">Menu</a></li>
						<li><a  href="addfood.php">Add Items</a></li>
						<li><a  href="admin_orders.php">All orders</a></li>
						<li><a  href="cust_msg.php">Customer messages</a></li>
						<li><a  href="useraccount.php">Your Account</a></li>
						<li><a  href="logout.php">Logout</a></li>
					</ul>					
						<span>There are many variations of passages</span>
				</div>
				<div class="col-md-4 footer-bottom  animated wow fadeInLeft" data-wow-duration="1000ms" data-wow-delay="500ms">
					<h2>Follow Us</h2>
					<label><i class="glyphicon glyphicon-menu-up"></i></label>
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis.</p>
					<ul class="social-ic">
						<li><a href="#"><i></i></a></li>
						<li><a href="#"><i class="ic"></i></a></li>
						<li><a href="#"><i class="ic1"></i></a></li>
						<li><a href="#"><i class="ic2"></i></a></li>
						<li><a href="#"><i class="ic3"></i></a></li>
					</ul>

				</div>
			<div class="clearfix"> </div>
					
			
	</div>		
	<!--//footer-->

		