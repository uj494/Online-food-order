<?php
session_start();
error_reporting(0);
require_once("modal/tablemodel.php");
$obj = new tablemodel();
$id = $_SESSION['id'];
$name = $_POST['data_3'];
$phone = $_POST['data_4'];
$email = $_POST['data_5'];
$date = $_POST['data_6'];
$time = $_POST['data_7'];
$guest = $_POST['data_8'];
$cmt = $_POST['data_9'];
$row = $obj->fetch_table();
if(!empty($row)){
	$tab = $obj->fetch_tableByDate($date, $time);
	if(!empty($tab)){
		$r = count($tab);
		if($r > 1){
			header("location: table.php?t=empty");
		} else {	
			header("location: paytable.php?name=".$name."&phone=".$phone."&email=".$email."&date=".$date."&time=".$time."&guest=".$guest."&cmt=".$cmt);
		//echo "hh";
		}
		
	} else {
		header("location: paytable.php?name=".$name."&phone=".$phone."&email=".$email."&date=".$date."&time=".$time."&guest=".$guest."&cmt=".$cmt);
		echo "done";
	}
} else {
	header("location: paytable.php?name=".$name."&phone=".$phone."&email=".$email."&date=".$date."&time=".$time."&guest=".$guest."&cmt=".$cmt);
	echo "done b";
}
?>