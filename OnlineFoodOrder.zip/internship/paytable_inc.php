<?php
session_start();
error_reporting(0);
require_once("modal/tablemodel.php");
require_once("modal/ordermodel.php");
$obj = new tablemodel();
$objcard = new ordermodel();
$id = $_SESSION['id'];
$name = $_POST['data_3'];
$phone = $_POST['data_4'];
$email = $_POST['data_5'];
$date = $_POST['data_6'];
$time = $_POST['data_7'];
echo $guest = $_POST['data_8'];
$cmt = $_POST['data_9'];
//$pay = $_POST['form'];
$status = "Confirmed";
if(is_numeric($_POST['form'])){
	$pay = "Credit/Debit Card";
	$card = $_POST['form'];
}else{
	$pay = $_POST['form'];
	if(!empty($_POST['card']))
	$card = $_POST['card'];
	else $card = "Not paid by card";
}
$obj->insert_table($id, $name, $email, $phone, $guest, $date, $time, $pay, $cmt, $status);

if (isset($_POST['saved'])) {
	$crd = $objcard->fetch_card($id, $card);
	if (empty($crd)) {
		$objcard->insert_card($id, $card);
	}
	
}
header("location: cust_table.php")
//echo "done";
?>