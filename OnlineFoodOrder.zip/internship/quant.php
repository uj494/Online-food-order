<?php
session_start();
error_reporting(0);
require_once("modal/menumodel.php");
require_once("modal/cartmodel.php");
require_once("modal/ordermodel.php");
$quant = $_REQUEST['quant'];
$item = $_REQUEST['item'];
$cost = $_REQUEST['cost'];
$c = $quant * $cost;
$obj = new cartmodel();
$id = $_SESSION['id'];
$obj->update_quant($item, $id, $quant, $c);
echo $c;
//echo $c;
?>