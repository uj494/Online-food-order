<?php
session_start();
error_reporting(0);
require_once("modal/msgmodel.php");

$obj = new msgmodel();
$id = $_SESSION['id'];
$name = $_POST['name'];
$phone = $_POST['phone'];
$email = $_POST['email'];
$msg = $_POST['msg'];

$obj->insert_msg($id, $name, $phone, $email, $msg);
header("location: contact.php?contact=success");
?>