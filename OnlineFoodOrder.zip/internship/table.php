<?php
session_start();
error_reporting(0);
if(!isset($_SESSION['id'])){
  header("location: index.php");
}
if(isset($_SESSION['page'])){
    unset($_SESSION['page']);
}
require_once("modal/custmodel.php");
?>
<!DOCTYPE html>
<html>
<head>
<title>My Hotel</title>
<link href="web/css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="web/js/jquery.min.js"></script>
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <link rel="stylesheet" href="/resources/demos/style.css">

  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  
<!-- Custom Theme files -->
<!--theme-style-->
<link href="web/css/style.css" rel="stylesheet" type="text/css" media="all" />  
<!--//theme-style-->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Cookery Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!---->
<link href='//fonts.googleapis.com/css?family=Raleway:400,200,100,300,500,600,700,800,900' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Open+Sans+Condensed:300,300italic,700' rel='stylesheet' type='text/css'>
<!-- start-smoth-scrolling -->
        <script type="text/javascript" src="web/js/move-top.js"></script>
        <script type="text/javascript" src="web/js/easing.js"></script>
        <script type="text/javascript">
            jQuery(document).ready(function($) {
                $(".scroll").click(function(event){     
                    event.preventDefault();
                    $('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
                });
            });
        </script>
        <!-- <script
        src="http://code.jquery.com/jquery-3.3.1.slim.js"
        integrity="sha256-fNXJFIlca05BIO2Y5zh1xrShK3ME+/lYZ0j+ChxX2DA="
        crossorigin="anonymous"></script> -->
    <!-- start-smoth-scrolling -->
<link href="web/css/styles.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="web/css/component.css" />
    <!-- animation-effect -->
<link href="web/css/animate.min.css" rel="stylesheet"> 
<script src="web/js/wow.min.js"></script>
<script>
 new WOW().init();
</script>
<script src="web/js/sweetalert-dev.js"></script>
  <link rel="stylesheet" href="web/css/sweetalert.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style type="text/css">
    hr.style13 {
    height: 10px;
    width: 710px;
    border: 0;
    box-shadow: 0 10px 10px -10px #8c8b8b inset;
}

.bigicon {
    font-size: 35px;
    color: #36A0FF;
}
.alert {
    padding: 10px;
    background-color: #f44336;
    color: white;
}
</style>
</head>
<body>
<div class="header head">
    <div class="container">
        <div class="logo animated wow pulse" data-wow-duration="1000ms" data-wow-delay="500ms">
            <h1><a href="index.php"><span>My Hotel</span></a></h1>
        </div>
        <div style="color: white; margin-left: 1000px; margin-top: 10px;">
        <?php
            $obj = new custmodel(); 
            $id = $_SESSION['id'];

            $row = $obj->fetch_userById($id);
            if(empty($row->profileimg)){
                 $src = "uploads/default.jpg";
             } else{
                 $src = "uploads/".$row->profileimg;
             }
        ?>
        <a href="cust_account.php"><img class='img-circle'style='height:50px; width:50px;' src='<?= $src ?>'/></a>
        
    </div>
        <div class="nav-icon" style="margin-top: -35px;">       
            <a href="#" class="navicon"></a>
                <div class="toggle">
                    <ul class="toggle-menu">
                        <li><a  href="cust_index.php">Home</a></li>
                        <li><a  href="cust_menu.php">Menu</a></li>
                        <li><a  href="cust_cart.php">Cart</a></li>
                        <li><a  href="table.php">Book your table</a></li>
                        <li><a  href="cust_table.php">Your bookings</a></li>
                        <li><a  href="your_orders.php">Orders</a></li>
                        <li><a  href="contact.php">Contact</a></li>
                        <li><a  class="active" href="cust_account.php">Your Account</a></li>
                        <li><a  href="cust_logout.php">Logout</a></li>
                    </ul>
                </div>
            <script>
            $('.navicon').on('click', function (e) {
              e.preventDefault();
              $(this).toggleClass('navicon--active');
              $('.toggle').toggleClass('toggle--active');
            });
            </script>
        </div>
    <div class="clearfix"></div>
    </div>
    <!-- start search-->    
        
</div>


<script>
  $( function() {
    $( "#datepicker" ).datepicker();
  } );
  </script>
  <?php
  if(!empty($_REQUEST['t'])){  

?>

        <div align="center" class="alert"   id="msg">
            <i class="fa fa-exclamation-circle" style="font-size:48px;"></i><h3><strong>Table unavailable at this time. Please choose different date or time!</strong></h3>
        </div>
<?php } ?>
<div class="container" style="width: 800px;">
    <div class="">
        <div class="">
            <div class="well well-sm">
                 <form method="post" style="padding-left: 200px;" onSubmit="return validateForm();" action="table_inc.php">
                    <div style="width: 400px;">
                    </div>
                    <div style="padding-bottom: 18px;"><h2><strong>Table Reservation</strong></h2></div>
                    <div style="padding-bottom: 18px;font-size : 18px;">We would be glad to reserve a table for you at our restaurant!</div>
                    <div style="padding-bottom: 18px;font-size : 18px;">We have 20 tables, so first check the availability and then proceed to book. We charge ₹100 per table.</div>
                    <div style="padding-bottom: 18px;"><label>Name</label><span style="color: red;"> *</span><br/>
                      <input type="text" id="data_3" name="data_3" required style="width : 400px;" class="form-control"/>
                    </div>
                    <div style="padding-bottom: 18px;"><label>Phone</label><br/>
                      <input type="text" id="data_4" name="data_4" style="width : 400px;" class="form-control" pattern= "[0-9]{10}"/>
                    </div>
                    <div style="padding-bottom: 18px;"><label>Email</label><br/>
                      <input type="email" id="data_5" name="data_5" style="width : 400px;" class="form-control"/>
                    </div>
                    <div style="padding-bottom: 18px;"><label>Date</label><span style="color: red;"> *</span><br/>
                      <input type="text" id="datepicker" name="data_6" required style="width : 250px;" class="form-control"/>
                    </div>
                    <div style="padding-bottom: 18px;"><label>Time</label><span style="color: red;"> *</span><br/>
                      <select id="data_7" name="data_7" required style="width : 250px;" class="form-control">
                    <option>10:00</option>
                    <option>11:00</option>
                    <option>12:00</option>
                    <option>13:00</option>
                    <option>14:00</option>
                    <option>15:00</option>
                    <option>16:00</option>
                    <option>17:00</option>
                    <option>18:00</option>
                    <option>19:00</option>
                    <option>20:00</option>
                    <option>21:00</option>
                    </select>
                    </div>
                    <div style="padding-bottom: 18px;"><label>Number of Attendees</label><span style="color: red;"> *</span><br/>
                    <select id="data_8" name="data_8" required style="width : 250px;" class="form-control"><option>1</option>
                    <option>2</option>
                    <option>3</option>
                    <option>4</option>
                    <option>5</option>
                    <option>6</option>
                    <option>7</option>
                    <option>8</option>
                    <option>9</option>
                    <option>10</option>
                    <option>If more then specify in comments</option>
                    </select>
                    </div>
                    <div style="padding-bottom: 18px;"><label>Comments / Additional Requests</label><br/>
                    <textarea id="data_9" false name="data_9" style="width : 400px;" rows="6" class="form-control"></textarea>
                    </div>
                    <div style="padding-bottom: 18px;"><input name="skip_Submit" value="Check availability" class="btn btn-primary" type="submit"/></div>
                    <div>
                  
</form>

            </div>
        </div>
    </div>
</div>
</div>
<!--footer-->
    <div class="footer">
        <div class="container">
            <div class="footer-head">
                <div class="col-md-8 footer-top animated wow fadeInRight" data-wow-duration="1000ms" data-wow-delay="500ms">
                    <ul class=" in">
                        <li><a  href="cust_index.php">Home</a></li>
                        <li><a  href="cust_menu.php">Menu</a></li>
                        <li><a  href="cust_cart.php">Cart</a></li>
                        <li><a  href="table.php">Book your table</a></li>
                        <li><a  href="cust_table.php">Your bookings</a></li>
                        <li><a  href="your_orders.php">Orders</a></li>
                        <li><a  href="contact.php">Contact</a></li>
                        <li><a  class="active" href="cust_account.php">Your Account</a></li>
                        <li><a  href="cust_logout.php">Logout</a></li>
                    </ul>                   
                        <span>There are many variations of passages</span>
                </div>
                <div class="col-md-4 footer-bottom  animated wow fadeInLeft" data-wow-duration="1000ms" data-wow-delay="500ms">
                    <h2>Follow Us</h2>
                    <label><i class="glyphicon glyphicon-menu-up"></i></label>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis.</p>
                    <ul class="social-ic">
                        <li><a href="#"><i></i></a></li>
                        <li><a href="#"><i class="ic"></i></a></li>
                        <li><a href="#"><i class="ic1"></i></a></li>
                        <li><a href="#"><i class="ic2"></i></a></li>
                        <li><a href="#"><i class="ic3"></i></a></li>
                    </ul>

                </div>
            <div class="clearfix"> </div>
                    
            
    </div>      
    <!--//footer-->