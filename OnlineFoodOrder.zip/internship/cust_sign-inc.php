<?php
	session_start();
	require_once("modal/custmodel.php");
//include 'C:\wamp64\www\internship\includes\dbh-inc.php';
//include 'C:\wamp64\www\internship\modal\usersmodel.php';

	$obj = new custmodel();
	if(!empty($_REQUEST['submit'])){
		$first = $_POST['fname'];
		$last = $_POST['lname'];
		$email = $_POST['ename'];
		$userid = $_POST['uname'];
		$password = $_POST['pwd'];
		if (empty($first)) {
			header('Location: cust_signup.php?error=empty');	
			exit();
		}
		if (empty($last)) {
			header('Location: cust_signup.php?error=empty');	
			exit();
		}
		if (empty($userid)) {
			header('Location: cust_signup.php?error=empty');	
			exit();
		}
		if (empty($email)) {
			header('Location: cust_signup.php?error=empty');	
			exit();
		}
		else{
			$recorduser = $obj->fetch_userUsername($userid);
			$row = $recorduser;
			if (!empty($row)) {
				header('Location: cust_signup.php?error=username');
				exit();	
			} else {
				$obj->insert_user($first, $last, $email, $userid, $password);
				header('Location: cust_login.php?signup=success');
			}
		}
	}


  /*$sql = "SELECT * FROM users WHERE username='$userid'";
 $result1 = $conn->query($sql);
 if (mysqli_num_rows($result1) > 0) {
 	while ($row = mysqli_fetch_assoc($result1)) {
 		$u_id = $row['user_id'];
 		$sql = "INSERT INTO profileimg (u_id, status) VALUES ('$u_id', 1);";
        $conn->query($sql);
 	}
 		} else {
 	echo "You have an error!";
 }*/
?>

</body>
</html>