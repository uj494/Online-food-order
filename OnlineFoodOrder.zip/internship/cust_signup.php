<?php
//include 'C:\wamp64\www\internship\includes\dbh-inc.php';
error_reporting(0);
//include 'C:\wamp64\www\internship\modal\usersmodel.php';
require_once("modal/custmodel.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>The Swaad</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="Login_v3/images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="Login_v3/vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="Login_v3/fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="Login_v3/fonts/iconic/css/material-design-iconic-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="Login_v3/vendor/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="Login_v3/vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="Login_v3/vendor/animsition/css/animsition.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="Login_v3/vendor/select2/select2.min.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="Login_v3/vendor/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="Login_v3/css/util.css">
	<link rel="stylesheet" type="text/css" href="Login_v3/css/main.css">
<!--===============================================================================================-->
<script src="web/js/sweetalert-dev.js"></script>
  <link rel="stylesheet" href="web/css/sweetalert.css">
<style type="text/css">
	
</style>
</head>
<body>
	<!-- action="cust_sign-inc.php" -->
	<div class="limiter" >
		<div class="center-block" style="background-image: url('Login_v3/images/img1.jpg');">
			
			<div class="wrap-login100" style="margin-left: 430px; ">
				<form class="login100-form validate-form" action="cust_sign-inc.php"  method="POST" >
					<span class="login100-form-logo">
						<i class="zmdi zmdi-landscape"></i>
					</span>

					<span class="login100-form-title p-b-34 p-t-27">
						Sign up as Customer
					</span>

					<div class="wrap-input100 validate-input" data-validate = "Enter fname">
						<input class="input100" type="text" name="fname" placeholder="Firstname">
						<span class="focus-input100" data-placeholder="&#xf207;"></span>
					</div>

					<div class="wrap-input100 validate-input" data-validate="Enter lname">
						<input class="input100" type="text" name="lname" placeholder="Lastname">
						<span class="focus-input100" data-placeholder="&#xf207;"></span>
					</div>

					<div class="wrap-input100 validate-input" data-validate="Enter uname">
						<input class="input100" type="email" name="ename" placeholder="E-mail">
						<span class="focus-input100" data-placeholder="&#xf207;"></span>
					</div>

					<div class="wrap-input100 validate-input" data-validate="Enter uname">
						<input class="input100" type="text" name="uname" placeholder="Username">
						<span class="focus-input100" data-placeholder="&#xf207;"></span>
					</div>

					<div class="wrap-input100 validate-input" data-validate="Enter password">
						<input class="input100" type="password" name="pwd" placeholder="Password" id="password"  onkeyup='check();'>
						<span class="focus-input100" data-placeholder="&#xf191;"></span>
					</div>

					<div class="wrap-input100 validate-input" data-validate="Enter password">
						<input class="input100" type="password" name="pwd2" placeholder="Confirm Password" id="confirm_password"  onkeyup='check();'>
						<span class="focus-input100" data-placeholder="&#xf191;"></span>
					</div>

						<span id='message'></span><br><br>
					<div style="margin-top: -10px;">
						<a class="txt1" href="cust_login.php">
							Already have an account? Log in.
						</a>
					</div><br>
					<div align="center">
						<a class="txt1" href="signup.php">
							Sign up as Admin.
						</a>
					</div>

					<?php

$url = "http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];

if (strpos($url, 'error=empty') !== false) {
	echo "<h2 align='center' style='color: white;'>FILL OUT ALL FEILDS!</h2>";	
}

elseif (strpos($url, 'error=username') !== false) {
	echo "<h3 align='center' style='color: white;'>Username exists!</h3>";	
}

if (isset($_SESSION['user_id'])) {
	echo "YOU ARE ALREADY LOGGED IN";
} 
?>
<br>
					<div class="container-login100-form-btn" style="margin-top: -20px;">
						
						<input type="submit" onclick="return passcheck();" name="submit" value="Sign up" class="login100-form-btn">
					</div>
				</form>
			</div>
		</div>
	</div>
	
	<script type="text/javascript">
  var check = function() {
  if (document.getElementById('password').value ==
    document.getElementById('confirm_password').value) {
    document.getElementById('message').style.color = 'green';
    document.getElementById('message').innerHTML = 'matching';
  } else {
    document.getElementById('message').style.color = 'red';
    document.getElementById('message').innerHTML = 'not matching';
  }
}
</script>
<script type="text/javascript">
	var passcheck = function() {
	if (document.getElementById('password').value ==
    document.getElementById('confirm_password').value) {
    return true;
  } else {
  	//alert("hh");
    JSalert("Passwords don't match!");
    return false;
  }
}
</script>
<script type="text/javascript">
    function JSalert(msg){
    swal({   title: msg,   
    
    type: "warning",   
    showCancelButton: false,   
    confirmButtonColor: "#FF0000",   
    confirmButtonText: "Ok",   
    cancelButtonText: "No!",   
    closeOnConfirm: true,   
    closeOnCancel: true }, 
    function(isConfirm){   
        if (isConfirm) 
    {   
        swal("Account Removed!", "Your account is removed permanently!", "success");
        } 
         });
}
</script>

	<div id="dropDownSelect1"></div>
	
<!--===============================================================================================-->
	<script src="Login_v3/vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="Login_v3/vendor/animsition/js/animsition.min.js"></script>
<!--===============================================================================================-->
	<script src="Login_v3/vendor/bootstrap/js/popper.js"></script>
	<script src="Login_v3/vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="Login_v3/vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="Login_v3/vendor/daterangepicker/moment.min.js"></script>
	<script src="Login_v3/vendor/daterangepicker/daterangepicker.js"></script>
<!--===============================================================================================-->
	<script src="Login_v3/vendor/countdowntime/countdowntime.js"></script>
<!--===============================================================================================-->
	<script src="Login_v3/js/main.js"></script>

</body>
</html>