<?php
error_reporting(0);
class controller{
	var $conn;

	//contructor
	function controller(){
		try{
			$this->conn = new PDO("mysql:host=localhost;dbname=hotel","root","");
		} catch(PDOException $e){
			echo $e->getMessage();
		}
	}

	function executeQuery($query){
		$pre = $this->conn->prepare($query);
		//var_dump($pre);
		$abc = $pre->execute();
		return $pre;
	}

	function fetchObject($recordSet){
		return $recordSet->fetchAll(PDO::FETCH_OBJ); 
	}
  	
  	function fetchSingleObject($recordSet){
		return $recordSet->fetch(PDO::FETCH_OBJ); 
	}


	function getId(){
		return $this->conn->lastInsertId();
	}
}
?>