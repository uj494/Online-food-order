<?php
require_once("controller/controller.php");

class msgmodel{
	var $cm;

	//constructor
	function msgmodel(){
		$this->cm = new controller();
	}

	function fetch_msg(){
		$query = "SELECT * FROM msg";
		$result = $this->cm->executeQuery($query);
		return $res = $this->cm->fetchObject($result);
	}

	function fetch_msgDesc(){
		$query = "SELECT * FROM msg ORDER BY id DESC";
		$result = $this->cm->executeQuery($query);
		return $res = $this->cm->fetchObject($result);
	}

	function fetch_msgById($id){
		$query = "SELECT * FROM msg WHERE id='$id'";
		$result = $this->cm->executeQuery($query);
		return $res = $this->cm->fetchSingleObject($result);
	}

	function fetch_msgByCustIdDesc($cust_id){
		$query = "SELECT * FROM msg WHERE custid='$cust_id' ORDER BY id DESC";
		$result = $this->cm->executeQuery($query);
		return $res = $this->cm->fetchObject($result);
	}

	function fetch_msgByCustId($cust_id){
		$query = "SELECT * FROM msg WHERE custid='$cust_id'";
		$result = $this->cm->executeQuery($query);
		return $res = $this->cm->fetchObject($result);
	}

	function insert_msg($custid, $name, $phone, $email, $msg){
		$query = "INSERT INTO msg(custid, name, email, msg, phone) VALUES('$custid', '$name', '$email', '$msg', '$phone')";
		//exit;
		$this->cm->executeQuery($query);
	}

	function delete_msg($id,$cust_id){
		$query = "DELETE FROM msg WHERE id='$id' AND custid='$cust_id'";
		$this->cm->executeQuery($query);
	}
}
?>