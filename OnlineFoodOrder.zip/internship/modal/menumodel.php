<?php
require_once("controller/controller.php");

class menumodel{
	var $cm;

	//constructor
	function menumodel(){
		$this->cm = new controller();
	}

	function fetch_menu($category){
		$query = "SELECT * FROM $category";
		$result = $this->cm->executeQuery($query);
		return $res = $this->cm->fetchObject($result);
	}

	function fetch_menuById($category, $id){
		$query = "SELECT * FROM $category WHERE id='$id'";
		$result = $this->cm->executeQuery($query);
		return $res = $this->cm->fetchSingleObject($result);
	}

	function fetch_menuByIdDesc($category, $id){
		$query = "SELECT * FROM $category WHERE id='$id' ORDER BY id DESC";
		$result = $this->cm->executeQuery($query);
		return $res = $this->cm->fetchSingleObject($result);
	}

	function insert_menu($category, $name, $quantity, $cost, $images){
		$query = "INSERT INTO $category(name, quantity, cost, images) VALUES('$name', '$quantity','$cost', '$images')";
		$this->cm->executeQuery($query);
	}

	function delete_menu($category, $id){
		$query = "DELETE FROM $category WHERE id=$id";
		$this->cm->executeQuery($query);
	}
}
?>