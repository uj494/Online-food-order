<?php
require_once("controller/controller.php");

class custmodel{
	var $cm;

	//constructor
	function custmodel(){
		$this->cm = new controller();
	}

	function fetch_user(){
		$query = "SELECT * FROM customer";
		$result = $this->cm->executeQuery($query);
		return $res = $this->cm->fetchObject($result);
	}

	function fetch_userUnamePass($username, $password){
		$query = "SELECT * FROM customer WHERE username='$username'AND password='$password' ";
		$result = $this->cm->executeQuery($query);
		return $res = $this->cm->fetchSingleObject($result);
	}

	function fetch_userUsername($username){
		$query = "SELECT * FROM customer WHERE username='$username'";
		$result = $this->cm->executeQuery($query);
		return $res = $this->cm->fetchSingleObject($result);
	}

	function update_custpass($id,$pass){
		$query = "UPDATE customer
				SET password = '$pass'
				WHERE id = '$id' ";
		$this->cm->executeQuery($query);
	}

	function update_custprofile($id, $fname, $lname, $email){
		$query = "UPDATE customer
				SET firstname = '$fname', lastname = '$lname', email = '$email'
				WHERE id = '$id' ";
		$this->cm->executeQuery($query);
	}

	function fetch_userById($id){
		$query = "SELECT * FROM customer WHERE id='$id'";
		$result = $this->cm->executeQuery($query);
		return $res = $this->cm->fetchSingleObject($result);
	}


	function insert_user($f, $l, $e, $u, $p){
		$query = "INSERT INTO customer(firstname, lastname, email, username, password) VALUES('$f', '$l', '$e','$u', '$p')";
		$this->cm->executeQuery($query);
	}

	function insert_profileimg($image, $id){
		echo $query = "INSERT INTO customer(profileimg) VALUES('$image') WHERE id='$id'";
		$this->cm->executeQuery($query);
	}

	function update_profileimg($image, $id){
		$query = "UPDATE customer
				SET profileimg = '$image'
				WHERE id = '$id'";
		$this->cm->executeQuery($query);
	}

	function delete_user($id){
		$query = "DELETE FROM customer WHERE id=$id";
		$this->cm->executeQuery($query);
	}
}
?>