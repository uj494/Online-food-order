<?php
require_once("controller/controller.php");

class cartmodel{
	var $cm;

	//constructor
	function cartmodel(){
		$this->cm = new controller();
	}

	function fetch_cart(){
		$query = "SELECT * FROM cart";
		$result = $this->cm->executeQuery($query);
		return $res = $this->cm->fetchObject($result);
	}

	function fetch_cartById($id){
		$query = "SELECT * FROM cart WHERE id='$id'";
		$result = $this->cm->executeQuery($query);
		return $res = $this->cm->fetchSingleObject($result);
	}

	function fetch_cartByCustId($cust_id){
		$query = "SELECT * FROM cart WHERE cust_id='$cust_id'";
		$result = $this->cm->executeQuery($query);
		return $res = $this->cm->fetchObject($result);
	}

	function fetch_cartByCatItem($category, $item_id, $cust_id){
		$query = "SELECT * FROM cart WHERE cust_id='$cust_id' AND category='$category' AND item_id='$item_id'";
		$result = $this->cm->executeQuery($query);
		return $res = $this->cm->fetchSingleObject($result);
	}

	function fetch_cartByCustItemId($cust_id, $item_id){
		$query = "SELECT * FROM cart WHERE cust_id='$cust_id' AND item_id='$item_id'";
		$result = $this->cm->executeQuery($query);
		return $res = $this->cm->fetchObject($result);
	}

	function insert_cart($category, $item_id, $cust_id, $rs){
		$query = "INSERT INTO cart(category, item_id, cust_id, quant, rs) VALUES('$category', '$item_id', '$cust_id', '1', '$rs')";
		$this->cm->executeQuery($query);
	}

	function insert_cartcost($cust_id, $rs){
		$query = "INSERT INTO cartcost(cust_id, rs) VALUES('$cust_id', '$rs')";
		$this->cm->executeQuery($query);
	}

	function update_quant($item_id, $cust_id, $quant, $rs){
		$query = "UPDATE cart
				SET quant = '$quant', rs = '$rs' 
				WHERE item_id = '$item_id' AND cust_id = '$cust_id'";
		$this->cm->executeQuery($query);
	}

	function delete_cart($id){
		$query = "DELETE FROM cart WHERE id=$id";
		$this->cm->executeQuery($query);
	}
	function delete_cartByCustId($cust_id){
		$query = "DELETE FROM cart WHERE cust_id=$cust_id";
		$this->cm->executeQuery($query);
	}
}
?>