<?php
require_once("controller/controller.php");

class usersmodel{
	var $cm;

	//constructor
	function usersmodel(){
		$this->cm = new controller();
	}

	function fetch_user(){
		$query = "SELECT * FROM users";
		$result = $this->cm->executeQuery($query);
		return $res = $this->cm->fetchObject($result);
	}

	function fetch_userUnamePass($username, $password){
		$query = "SELECT * FROM users WHERE username='$username'AND password='$password' ";
		$result = $this->cm->executeQuery($query);
		return $res = $this->cm->fetchSingleObject($result);
	}

	function fetch_userUsername($username){
		$query = "SELECT * FROM users WHERE username='$username'";
		$result = $this->cm->executeQuery($query);
		return $res = $this->cm->fetchSingleObject($result);
	}

	function update_pass($id,$pass){
		$query = "UPDATE users
				SET password = '$pass'
				WHERE id = '$id' ";
		$this->cm->executeQuery($query);
	}

	function update_profile($id, $fname, $lname){
		$query = "UPDATE users
				SET firstname = '$fname', lastname = '$lname'
				WHERE id = '$id' ";
		$this->cm->executeQuery($query);
	}

	function fetch_userById($id){
		$query = "SELECT * FROM users WHERE id='$id'";
		$result = $this->cm->executeQuery($query);
		return $res = $this->cm->fetchSingleObject($result);
	}


	function insert_user($f, $l, $u, $p){
		$query = "INSERT INTO users(firstname, lastname, username, password) VALUES('$f', '$l','$u', '$p')";
		$this->cm->executeQuery($query);
	}

	function delete_user($id){
		$query = "DELETE FROM users WHERE id=$id";
		$this->cm->executeQuery($query);
	}
}
?>