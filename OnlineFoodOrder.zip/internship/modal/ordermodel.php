<?php
require_once("controller/controller.php");

class ordermodel{
	var $cm;

	//constructor
	function ordermodel(){
		$this->cm = new controller();
	}

	function fetch_order(){
		$query = "SELECT * FROM orders";
		$result = $this->cm->executeQuery($query);
		return $res = $this->cm->fetchObject($result);
	}

	function fetch_orderDesc(){
		$query = "SELECT * FROM orders ORDER BY id DESC";
		$result = $this->cm->executeQuery($query);
		return $res = $this->cm->fetchObject($result);
	}

	function fetch_orderById($id){
		$query = "SELECT * FROM orders WHERE id='$id'";
		$result = $this->cm->executeQuery($query);
		return $res = $this->cm->fetchSingleObject($result);
	}

	function fetch_orderByCustIdDesc($cust_id){
		$query = "SELECT * FROM orders WHERE custid='$cust_id' ORDER BY id DESC";
		$result = $this->cm->executeQuery($query);
		return $res = $this->cm->fetchObject($result);
	}

	function fetch_orderByCustId($cust_id){
		$query = "SELECT * FROM orders WHERE custid='$cust_id'";
		$result = $this->cm->executeQuery($query);
		return $res = $this->cm->fetchObject($result);
	}

	function update_status($id, $status){
		$query = "UPDATE orders
				SET status = '$status'
				WHERE id = '$id' ";
		$this->cm->executeQuery($query);
	}


	function insert_order($custid, $item_name, $quant, $quant2, $img, $cost, $receiver, $phone, $address, $address2, $city, $zipcode, $date, $paymode, $status, $card){
		$query = "INSERT INTO orders(custid, item_name, quantity, quantity2, img, cost, receiver, phone, address, address2, city, zipcode, pay, date1, status, card) VALUES('$custid', '$item_name', '$quant', '$quant2', '$img', '$cost', '$receiver', '$phone', '$address', '$address2', '$city', '$zipcode', '$paymode', '$date', '$status', '$card')";
		//exit;
		$this->cm->executeQuery($query);
	}

	function insert_add($cust_id, $receiver, $add1, $add2, $city, $zipcode, $phone){
		$query = "INSERT INTO address(cust_id, receiver, add1, add2, city, zipcode,  phone) VALUES('$cust_id', '$receiver', '$add1', '$add2', '$city', '$zipcode', '$phone')";
		//exit;
		$this->cm->executeQuery($query);
	}

	function fetch_add($custid, $receiver){
		$query = "SELECT * FROM address WHERE cust_id='$custid' AND receiver='$receiver'";
		$result = $this->cm->executeQuery($query);
		return $res = $this->cm->fetchObject($result);
	}

	function fetch_addById($id){
		$query = "SELECT * FROM address WHERE id='$id'";
		$result = $this->cm->executeQuery($query);
		return $res = $this->cm->fetchSingleObject($result);
	}

	function fetch_alladd($custid){
		$query = "SELECT * FROM address WHERE cust_id='$custid'";
		$result = $this->cm->executeQuery($query);
		return $res = $this->cm->fetchObject($result);
	}

	function delete_add($id){
		$query = "DELETE FROM address WHERE id='$id'";
		$this->cm->executeQuery($query);
	}

	function insert_card($custid, $card){
		$query = "INSERT INTO card(cust_id, card) VALUES('$custid', '$card')";
		//exit;
		$this->cm->executeQuery($query);
	}

	function fetch_card($custid, $card){
		$query = "SELECT * FROM card WHERE cust_id='$custid' AND card='$card'";
		$result = $this->cm->executeQuery($query);
		return $res = $this->cm->fetchObject($result);
	}

	function delete_card($id){
		$query = "DELETE FROM card WHERE id='$id'";
		$this->cm->executeQuery($query);
	}

	function fetch_allcard($custid){
		$query = "SELECT * FROM card WHERE cust_id='$custid'";
		$result = $this->cm->executeQuery($query);
		return $res = $this->cm->fetchObject($result);
	}

	function delete_order($id,$cust_id){
		$query = "DELETE FROM orders WHERE id='$id' AND custid='$cust_id'";
		$this->cm->executeQuery($query);
	}
}
?>