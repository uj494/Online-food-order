<?php
require_once("controller/controller.php");

class tablemodel{
	var $cm;

	//constructor
	function tablemodel(){
		$this->cm = new controller();
	}

	function fetch_table(){
		$query = "SELECT * FROM booktable";
		$result = $this->cm->executeQuery($query);
		return $res = $this->cm->fetchObject($result);
	}

	function fetch_tableDesc(){
		$query = "SELECT * FROM booktable ORDER BY id DESC";
		$result = $this->cm->executeQuery($query);
		return $res = $this->cm->fetchObject($result);
	}

	function fetch_tableById($id){
		$query = "SELECT * FROM booktable WHERE id='$id'";
		$result = $this->cm->executeQuery($query);
		return $res = $this->cm->fetchSingleObject($result);
	}

	function fetch_tableByDate($date, $time){
		$query = "SELECT * FROM booktable WHERE date2='$date' AND time2='$time' AND status='Confirmed'";
		$result = $this->cm->executeQuery($query);
		return $res = $this->cm->fetchObject($result);
	}

	function fetch_tableByCustIdDesc($cust_id){
		$query = "SELECT * FROM booktable WHERE custid='$cust_id' ORDER BY id DESC";
		$result = $this->cm->executeQuery($query);
		return $res = $this->cm->fetchObject($result);
	}

	function fetch_tableByCustId($cust_id){
		$query = "SELECT * FROM booktable WHERE custid='$cust_id'";
		$result = $this->cm->executeQuery($query);
		return $res = $this->cm->fetchObject($result);
	}

	function update_table($id){
		$query = "UPDATE booktable
				SET status = 'Cancelled'
				WHERE id = '$id' ";
		$this->cm->executeQuery($query);
	}


	function insert_table($custid, $name, $email, $phone, $guest, $date, $time, $pay, $cmt, $status){
		$query = "INSERT INTO booktable(custid, fullname, email, phone, guest, date2, time2, pay, cmt, status) VALUES('$custid', '$name', '$email', '$phone', '$guest', '$date', '$time', '$pay', '$cmt', '$status')";
		//exit;
		$this->cm->executeQuery($query);
	}

	function delete_table($id){
		$query = "DELETE FROM booktable WHERE id='$id'";
		$this->cm->executeQuery($query);
	}
}
?>