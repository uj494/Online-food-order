<?php
session_start();
error_reporting(0);
if(!isset($_SESSION['id'])){
    header("location: index.php");
}
require_once("modal/menumodel.php");
require_once("modal/cartmodel.php");
require_once("modal/ordermodel.php");
require_once("modal/custmodel.php");
$obj = new menumodel();
$objcart = new cartmodel();
$objorder = new ordermodel();

//var_dump($cart);


/*foreach ($cart as $key) {
    $cartid = $key->id;
    $objorder->insert_order($id, $cartid, $name, $phone, $street1, $street2, $city, $state, $zip, $date); 
    //$objcart->delete_cart($cartid);
}*/
//exit;

//header("location: your_orders.php");
?>
<!DOCTYPE html>
<html>
<head>
<title>My Hotel</title>
<link href="web/css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="web/js/jquery.min.js"></script>
<!-- Custom Theme files -->
<!--theme-style-->
<link href="web/css/style.css" rel="stylesheet" type="text/css" media="all" />  
<!--//theme-style-->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Cookery Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!---->
<link href='//fonts.googleapis.com/css?family=Raleway:400,200,100,300,500,600,700,800,900' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Open+Sans+Condensed:300,300italic,700' rel='stylesheet' type='text/css'>
<!-- start-smoth-scrolling -->
        <script type="text/javascript" src="web/js/move-top.js"></script>
        <script type="text/javascript" src="web/js/easing.js"></script>
        <script type="text/javascript">
            jQuery(document).ready(function($) {
                $(".scroll").click(function(event){     
                    event.preventDefault();
                    $('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
                });
            });
        </script>
    <!-- start-smoth-scrolling -->
<link href="web/css/styles.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="web/css/component.css" />
    <!-- animation-effect -->
<link href="web/css/animate.min.css" rel="stylesheet"> 
<script src="web/js/wow.min.js"></script>
<script>
 new WOW().init();
</script>
<!-- //animation-effect -->

</head>
<body>
<div class="header head">
    <div class="container">
        <div class="logo animated wow pulse" data-wow-duration="1000ms" data-wow-delay="500ms">
            <h1><a href="index.php"><span>My Hotel</span></a></h1>
        </div>
        <div style="color: white; margin-left: 1000px; margin-top: 10px;">
        <?php
            $objcust = new custmodel(); 
            $id = $_SESSION['id'];

            $row = $objcust->fetch_userById($id);
            if(empty($row->profileimg)){
                 $src = "uploads/default.jpg";
             } else{
                 $src = "uploads/".$row->profileimg;
             }
        ?>
            <a href="cust_account.php"><img class='img-circle' id="img1" style='height:50px; width:50px;' src='<?= $src ?>'/></a>
        </div>
        <div class="nav-icon" style="margin-top: -35px;">       
            <a href="#" class="navicon"></a>
                <div class="toggle">
                    <ul class="toggle-menu">
                        <li><a  href="cust_index.php">Home</a></li>
                        <li><a  href="cust_menu.php">Menu</a></li>
                        <li><a  class="active" href="cust_cart.php">Cart</a></li>
                        <li><a  href="table.php">Book your table</a></li>
                        <li><a  href="cust_table.php">Your bookings</a></li>
                        <li><a  href="your_orders.php">Orders</a></li>
                        <li><a  href="contact.html">Contact</a></li>
                        <li><a  href="cust_account.php">Your Account</a></li>
                        <li><a  href="cust_logout.php">Logout</a></li>
                    </ul>
                </div>
            <script>
            $('.navicon').on('click', function (e) {
              e.preventDefault();
              $(this).toggleClass('navicon--active');
              $('.toggle').toggleClass('toggle--active');
            });
            </script>
        </div>
    <div class="clearfix"></div>
    </div>
</div><br><br>
<style type="text/css">
    .creditCardForm {
    max-width: 700px;
    margin: 100px auto;
    overflow: hidden;
    padding: 25px;
    color: #4c4e56;
}

.creditCardForm label {
    width: 100%;
    margin-bottom: 10px;
}

.creditCardForm .heading h1 {
    text-align: center;
    font-family: 'Open Sans', sans-serif;
    color: #4c4e56;
}

.creditCardForm .payment {
    float: left;
    font-size: 18px;
    padding: 10px 25px;
    margin-top: 20px;
    position: relative;
}

.creditCardForm .payment .form-group {
    float: left;
    margin-bottom: 15px;
}

.creditCardForm .payment .form-control {
    line-height: 40px;
    height: auto;
    padding: 0 16px;
}

.creditCardForm .owner {
    width: 63%;
    margin-right: 10px;
}

.creditCardForm .CVV {
    width: 35%;
}

.creditCardForm #card-number-field {
    width: 100%;
}

.creditCardForm #expiration-date {
    width: 49%;
}

.creditCardForm #credit_cards {
    width: 50%;
    margin-top: 25px;
    text-align: right;
}

.creditCardForm #pay-now {
    width: 100%;
    margin-top: 25px;
}

.creditCardForm .payment .btn {
    width: 100%;
    margin-top: 3px;
    font-size: 24px;
    background-color: #2ec4a5;
    color: white;
}

.creditCardForm .payment select {
    padding: 10px;
    margin-right: 15px;
}

.transparent {
    opacity: 0.2;
}

@media(max-width: 650px) {
    .creditCardForm .owner,
    .creditCardForm .CVV,
    .creditCardForm #expiration-date,
    .creditCardForm #credit_cards {
        width: 100%;
    }
    .creditCardForm #credit_cards {
        text-align: left;
    }
}


/*  Examples Section */

.examples {
    max-width: 700px;
    
    margin: 0 auto 75px;
    padding: 30px 50px;
    color: #4c4e56;
}

.examples-note{
    text-align: center;
    font-size: 14px;
    max-width: 370px;
    margin: 0 auto 40px;
    line-height: 1.7;
    color: #7a7a7a;
}

.examples table {
    margin: 5px 0 0 0;
    font-size: 14px;
}

*{
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}



.container-fluid{
    padding:0;
    margin:0;
}


</style>


<h2 align="center">Mode of payment</h2><br>
<div style="padding: 40px;">

    <script type='text/javascript'>
         
function displayForm(c) {
    $("#one").change(function(){

       $("#two").prop("checked", false);
       $("#three").prop("checked", false);

});
$("#two").change(function(){

       $("#one").prop("checked", false);
       $("#three").prop("checked", false);

});
$("#three").change(function(){

       $("#one").prop("checked", false);
       $("#two").prop("checked", false);

});
    

    if (c.value == "Paypal") {    
        jQuery('#paypalformContainer').toggle('show');
        jQuery('#ccformContainer').hide();
        var z = document.forms["orderpay"]["count"].value;
          for (i = 1; i < z; i++) {
            jQuery('#save'+i).hide();
           }
    }
        if (c.value == "Credit card") {
         jQuery('#ccformContainer').toggle('show');
         jQuery('#paypalformContainer').hide();

         var z = document.forms["orderpay"]["count"].value;
          for (i = 1; i < z; i++) {
            jQuery('#save'+i).hide();
           }
    }

    if(!isNaN(c.value)){
        jQuery('#ccformContainer').hide();
        jQuery('#paypalformContainer').hide();
        var a = c.id;
        var arr = a.match(/\d+/)[0];
        var b = arr;
        //alert(b);
        var z = document.forms["orderpay"]["count"].value;
        //alert(z);
         jQuery('#save'+b).toggle('show');
          for (i = 1; i < z; i++) {
            if (i != b) {
                //alert(i);
            jQuery('#save'+i).hide();
            }
            
            }
         
    }
};
</script>
<script type="text/javascript">
        function check(con) {
            //alert("hh");
            
              for (var  count = 1; count < con; count++) {
            if(document.getElementById('ab'+count).checked){
                var a=document.forms["orderpay"]["c"+count].value;
                if(a==""){
                    document.getElementById('msg1'+count).innerHTML = 'Please fill valid CVV!';
                    return false;
                    
                } else return true;
            } 
        }
            if(document.getElementById('one').checked){
                var a=document.forms["orderpay"]["owner"].value;
                var b=document.forms["orderpay"]["cvv2"].value;
                var c=document.forms["orderpay"]["card"].value;
                var d=document.forms["orderpay"]["exm"].value;
                var e=document.forms["orderpay"]["exy"].value;
                if((a=="") || (b=="") || (c=="") || (d=="") || (e=="")){
                    document.getElementById('msg2').innerHTML = 'Please fill all the fields!';
                    return false;
                } else return true;
            } 
            if(document.getElementById('two').checked){
                var a=document.forms["orderpay"]["paypal"].value;
                if(a==""){
                    document.getElementById('msg3').innerHTML = 'Please fill the valid Paypal address!';
                    return false;
                } else return true;
            }
            document.getElementById('sub').innerHTML = 'Please select one!';
            return false;
    }
</script>
<script type="text/javascript">
    $(function(){
    $('.del').click(function(){
        //e.preventDefault();
        var id = $(this).attr("id");
        var sta = $("#dis"+id).attr("id");
        $.post("delcard.php?id="+id,function(data){
                //alert(data);
                jQuery("#dis"+id).hide();
            });
    });
});
</script>
</head>
<body>

<?php
$id = $_SESSION['id'];
$name = $_REQUEST['name'];
$phone = $_REQUEST['phone'];
$email = $_REQUEST['email'];
$date = $_REQUEST['date'];
$time = $_REQUEST['time'];
$guest = $_REQUEST['guest'];
$cmt = $_REQUEST['cmt'];
$cards = $objorder->fetch_allcard($id);
function ccMasking($number) {
    return substr($number, 0, 4) . str_repeat("X", strlen($number) - 8) . substr($number, -4);
            /*document.getElementById('crd').innerHTML = c;*/
           
     }
     ?>
 <form method="post" name="orderpay" action="paytable_inc.php">
    <?php
        if(!empty($cards)){
            $count = 1;
            echo "<div class='well' style='border-color: blue; width: 250px;'>";
            echo "<h4>Saved Cards</h4><br>";
            foreach ($cards as $key) {
    ?>
    
        <div id="dis<?=$key->id?>">
        <input type="radio" name="form" id="ab<?=$count?>" value="<?=$key->card?>" onClick="displayForm(this)">&nbsp;<strong><?php echo ccMasking($key->card)?></strong>&nbsp;|&nbsp;<a style="cursor: pointer;" class="del" id="<?=$key->id?>">Delete</a>
        </div><br>
        <div style="display:none" id="save<?=$count?>">
        <label style="margin-left: 20px;">CVV</label>
        <input style="width: 100px; margin-left: 20px;" type="text" class="form-control" name="c<?=$count?>" pattern= "[0-9]{3}">
        <div id="msg1<?=$count?>" style="color: red; margin-left: 20px; margin-top: 10px;"></div>
    </div>
    <br>
    <?php 
            $count++;
            }
            echo "</div>";
        } 
    ?>
    <input type="hidden" name="count" value="<?=$count?>">
    <input style="float: left;" value="Credit card" type="radio" id="one" name="form" onClick="displayForm(this)"></input>&nbsp;&nbsp;
    <h4 style="float: left;margin-left: 5px;"><label>Via Credit Card</label></h4>
        <input type="hidden" name="data_3" value='<?php echo "$name";?>'>
    <input type="hidden" name="data_4" value='<?php echo "$phone";?>'>
    <input type="hidden" name="data_5" value='<?php echo "$email";?>'>
    <input type="hidden" name="data_6" value='<?php echo "$date";?>'>
    <input type="hidden" name="data_7" value='<?php echo "$time";?>'>
    <input type="hidden" name="data_8" value='<?php echo "$guest";?>'>
    <input type="hidden" name="data_9" value='<?php echo "$cmt";?>'>
    <div style="display:none; margin-top: 10px;" id="ccformContainer">
        <div class="payment">
                    <div class="form-group owner">
                        <label for="owner">Owner</label>
                        <input type="text" name="owner" class="form-control" id="owner">
                    </div>
                    <div class="form-group CVV">
                        <label for="cvv">CVV</label>
                        <input type="text" name="cvv2" class="form-control" id="cvv" pattern= "[0-9]{3}">
                    </div>
                    <div class="form-group" id="card-number-field">
                        <label for="cardNumber">Card Number</label>
                        <input type="text" name="card" class="form-control" id="cardNumber" pattern= "[0-9]{16}">
                    </div>
                    <div class="form-group" id="expiration-date">
                        <label>Expiration Date</label>
                        <select name="exm">
                            <option value="01">January</option>
                            <option value="02">February </option>
                            <option value="03">March</option>
                            <option value="04">April</option>
                            <option value="05">May</option>
                            <option value="06">June</option>
                            <option value="07">July</option>
                            <option value="08">August</option>
                            <option value="09">September</option>
                            <option value="10">October</option>
                            <option value="11">November</option>
                            <option value="12">December</option>
                        </select>
                        <select name="exy">
                            <option value="18"> 2018</option>
                            <option value="19"> 2019</option>
                            <option value="20"> 2020</option>
                            <option value="21"> 2021</option>
                            <option value="16"> 2022</option>
                            <option value="17"> 2023</option>
                        </select>
                    </div>
                    <div class="form-group" id="credit_cards">
                        <img src="img/visa.jpg" id="visa">
                        <img src="img/mastercard.jpg" id="mastercard">
                        <img src="img/amex.jpg" id="amex">
                    </div>
            </div>
            <input type="checkbox" name="saved">&nbsp;<strong>Save this card for faster checkout.</strong><br>
            <div id="msg2" style="color: red; margin-top: 10px;"></div>
    </div><br>
    <br>
    <input style="float: left;" value="Paypal" type="radio" id="two" name="form" onClick="displayForm(this)"></input>&nbsp;&nbsp;
    <h4 style="float: left;margin-left: 5px;"><label>Via Paypal</label></h4>
    <div style="display:none; margin-top: 10px;" id="paypalformContainer">
        <label>Enter your Paypal Details</label>
        <br>
        <br>
        <dd>Paypal Address :
            <input type="text" id="paypal" name="paypal">
        </dd><br>
        <div id="msg3" style="color: red;"></div>
    </div><br><br>
    <div id="sub" style="color: red;"></div>
    <br>
    <div id="float_right">
        
    <input type="submit" class="btn btn-primary" name="pay" value="Pay now" onclick = "return check(<?=$count?>);">
    &nbsp;&nbsp;<a href="order_detail.php" class="btn btn-primary">Back</a>
    </div>

</form><br><br>
<!--footer-->
    <div class="footer">
        <div class="container">
            <div class="footer-head">
                <div class="col-md-8 footer-top animated wow fadeInRight" data-wow-duration="1000ms" data-wow-delay="500ms">
                    <ul class=" in">
                        <li><a  href="cust_index.php">Home</a></li>
                        <li><a  href="cust_menu.php">Menu</a></li>
                        <li><a  href="cust_cart.php">Cart</a></li>
                        <li><a  href="table.php">Book your table</a></li>
                        <li><a  href="cust_table.php">Your bookings</a></li>
                        <li><a  href="your_orders.php">Orders</a></li>
                        <li><a  href="contact.php">Contact</a></li>
                        <li><a  class="active" href="cust_account.php">Your Account</a></li>
                        <li><a  href="cust_logout.php">Logout</a></li>
                    </ul>                   
                        <span>There are many variations of passages</span>
                </div>
                <div class="col-md-4 footer-bottom  animated wow fadeInLeft" data-wow-duration="1000ms" data-wow-delay="500ms">
                    <h2>Follow Us</h2>
                    <label><i class="glyphicon glyphicon-menu-up"></i></label>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis.</p>
                    <ul class="social-ic">
                        <li><a href="#"><i></i></a></li>
                        <li><a href="#"><i class="ic"></i></a></li>
                        <li><a href="#"><i class="ic1"></i></a></li>
                        <li><a href="#"><i class="ic2"></i></a></li>
                        <li><a href="#"><i class="ic3"></i></a></li>
                    </ul>

                </div>
            <div class="clearfix"> </div>
                    
            
       </div>       
    </div>
</div>

    <!--//footer-->


