<?php
session_start();
error_reporting(0);
require_once("modal/cartmodel.php");

$obj = new cartmodel();

echo $id = $_REQUEST['id'];


$obj->delete_cart($id);
header("location: cust_cart.php?cart=remove")
?>