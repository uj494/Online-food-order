<?php
session_start();
error_reporting(0);
require_once("modal/tablemodel.php");;
$obj = new tablemodel();
$id = $_REQUEST['id'];
$obj->update_table($id);
header("location: cust_table.php")
?>