<?php
session_start();
error_reporting(0);
if(!isset($_SESSION['id'])){
	header("location: index.php");
}

require_once("modal/msgmodel.php");
require_once("modal/custmodel.php");

?>
<!DOCTYPE html>
<html>
<head>
<title>My Hotel</title>
<link href="web/css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="web/js/jquery.min.js"></script>
<!-- Custom Theme files -->
<!--theme-style-->
<link href="web/css/style.css" rel="stylesheet" type="text/css" media="all" />	
<!--//theme-style-->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Cookery Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!---->
<link href='//fonts.googleapis.com/css?family=Raleway:400,200,100,300,500,600,700,800,900' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Open+Sans+Condensed:300,300italic,700' rel='stylesheet' type='text/css'>
<!-- start-smoth-scrolling -->
		<script type="text/javascript" src="web/js/move-top.js"></script>
		<script type="text/javascript" src="web/js/easing.js"></script>
		<script type="text/javascript">
			jQuery(document).ready(function($) {
				$(".scroll").click(function(event){		
					event.preventDefault();
					$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
				});
			});
		</script>
	<!-- start-smoth-scrolling -->
<link href="web/css/styles.css" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="web/css/component.css" />
	<!-- animation-effect -->
<link href="web/css/animate.min.css" rel="stylesheet"> 
<script src="web/js/wow.min.js"></script>
<script>
 new WOW().init();
</script>
<style>/* Flaired edges, by Tomas Theunissen */

hr.style-one {
	border: 1px;
	height: 1px;
	
	background-image: linear-gradient(to right, #ccc, #333, #ccc); 
}

hr.style-seven {
    overflow: visible; /* For IE */
    height: 30px;
    width: 580px;
    border-style: solid;
    border-color: black;
    border-width: 1px 0 0 0;
    border-radius: 20px;
}
hr.style-seven:before { /* Not really supposed to work, but does */
    display: block;
    content: "";
    height: 30px;
    margin-top: -31px;
    border-style: solid;
    border-color: black;
    border-width: 0 0 1px 0;
    border-radius: 20px;
}

.floatLeft {
	width: 50%;
	float: left;
	margin-left: -80px;
}

.floatRight {
	width: 50%;
	float: right;
	margin-top: 35px;
}
</style>
<!-- //animation-effect -->

</head>
<body>
<div class="header head">
	<div class="container">
		<div class="logo animated wow pulse" data-wow-duration="1000ms" data-wow-delay="500ms">
			<h1><a href="index.php"><span>My Hotel</span></a></h1>
		</div>
		<div class="nav-icon">		
			<a href="#" class="navicon"></a>
				<div class="toggle">
					<ul class="toggle-menu">
						<li><a  href="admin_index.php">Home</a></li>
						<li><a  href="admin_menu.php">Menu</a></li>
						<li><a  href="addfood.php">Add Items</a></li>
						<li><a  href="admin_orders.php">All Orders</a></li>
						<li><a  class="active"  href="cust_msg.php">Customer messages</a></li>
						<li><a  href="useraccount.php">Your Account</a></li>
						<li><a  href="logout.php">Logout</a></li>
					</ul>
				</div>
			<script>
			$('.navicon').on('click', function (e) {
			  e.preventDefault();
			  $(this).toggleClass('navicon--active');
			  $('.toggle').toggleClass('toggle--active');
			});
			</script>
		</div>
	<div class="clearfix"></div>
	</div>
	<!-- start search-->	
		
</div><br>

	
		<div class="logo animated wow pulse" style="margin-top: -7px; margin-left: 20px;">
			<h1>Customer messages</h1>
			<hr class="style-seven">
		</div><br><div class="clearfix"> </div>
<div>

<style type="text/css">
	td {
		padding-right: 20px;
		padding-left: 30px;
		padding-top: 15px;
		width: 200px;
	}

	th {
		padding-right: 20px;
		padding-left: 30px;
		padding-top: 15px;
		width: 200px;
	}
	
</style>
	
<?php
//echo $_SESSION['id'];
$obj = new msgmodel();
$id = $_SESSION['id'];
$row = $obj->fetch_msg();



if(!empty($row)){
	echo "<div  class=''>";
				echo "<table><tr>
						<th><p style='padding-left:10px;'>Name</p></th>
						<th>Phone</th>
						<th>E-mail</th>
						<th>Message</th>
						</tr>";
	foreach ($row as $msg){
				
				echo "<tr><th><li><h4 style='padding-left:10px;'>".$msg->name."</h4></li></th>
						<td>".$msg->phone."</td>
						<td><p><a href='mailto:".$msg->email."?Subject=My%20Hotel' target='_top'>".$msg->email."</p></td>
						<td>".$msg->msg."</td>
						<td width='70%''>".$msg->date1."</td>
						</tr>";
				
				

			}
		
			echo "</table></div>";
	
?>

	
<?php
} else{
	echo "<div style='padding-left:20px;'>
		 <h2>No messages till now.</h2>
		 </div>";
}
?>
<div class="clearfix"></div><br><br>
	<div style="text-align: center;">
		<a href="admin_menu.php" style="background-color: blue; color: white; display: inline-block; padding: 10px 30px; border-radius: 8px;">Proceed to menu</a>
	</div>
</div></div>
</div><br><br>

<script type="text/javascript">
	$(function(){
		$(".btn").click(function(){
			var id = $(this).attr("id");
			var sta = $("#status"+id).html();
			//alert(sta);
			//$.post("status.php?edit="+id+"&status="+sta);
			$.post("status.php?edit="+id+"&status="+sta,function(data){
				//alert(data);
				$("#status"+id).html(data);
				jQuery("#"+id).hide();
			});
		});
	});
</script>
<!--footer-->
	<div class="footer">
		<div class="container">
			<div class="footer-head">
				<div class="col-md-8 footer-top animated wow fadeInRight" data-wow-duration="1000ms" data-wow-delay="500ms">
					<ul class=" in">
						<li><a href="index.html">Home</a></li>
						<li><a  href="menu.html">Menu</a></li>
						<li><a  href="orders.php">Your Orders</a></li>
						<li><a  href="cart.php">Your Cart</a></li>
						<li><a  href="events.html">Events</a></li>
						<li><a  href="contact.html">Contact</a></li>
					</ul>					
						<span>There are many variations of passages</span>
				</div>
				<div class="col-md-4 footer-bottom  animated wow fadeInLeft" data-wow-duration="1000ms" data-wow-delay="500ms">
					<h2>Follow Us</h2>
					<label><i class="glyphicon glyphicon-menu-up"></i></label>
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis.</p>
					<ul class="social-ic">
						<li><a href="#"><i></i></a></li>
						<li><a href="#"><i class="ic"></i></a></li>
						<li><a href="#"><i class="ic1"></i></a></li>
						<li><a href="#"><i class="ic2"></i></a></li>
						<li><a href="#"><i class="ic3"></i></a></li>
					</ul>

				</div>
			<div class="clearfix"> </div>
					
			
	</div>		
	<!--//footer-->

		