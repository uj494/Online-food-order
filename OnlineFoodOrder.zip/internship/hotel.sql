-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 29, 2018 at 08:34 AM
-- Server version: 5.7.14
-- PHP Version: 7.0.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hotel`
--

-- --------------------------------------------------------

--
-- Table structure for table `address`
--

CREATE TABLE `address` (
  `id` int(11) NOT NULL,
  `cust_id` int(11) NOT NULL,
  `receiver` varchar(30) NOT NULL,
  `add1` varchar(255) NOT NULL,
  `add2` varchar(255) NOT NULL,
  `city` varchar(30) NOT NULL,
  `zipcode` int(30) NOT NULL,
  `phone` varchar(30) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `address`
--

INSERT INTO `address` (`id`, `cust_id`, `receiver`, `add1`, `add2`, `city`, `zipcode`, `phone`) VALUES
(3, 1, 'Ujjwal Soni', 'H Number 205 FCI road', 'Opposite natraj talkies', 'Chennai', 324002, '9001996520');

-- --------------------------------------------------------

--
-- Table structure for table `booktable`
--

CREATE TABLE `booktable` (
  `id` int(11) NOT NULL,
  `custid` int(11) NOT NULL,
  `fullname` varchar(30) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` varchar(30) NOT NULL,
  `guest` varchar(255) NOT NULL,
  `date2` varchar(30) NOT NULL,
  `time2` varchar(50) NOT NULL,
  `pay` varchar(30) NOT NULL,
  `cmt` varchar(255) NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `booktable`
--

INSERT INTO `booktable` (`id`, `custid`, `fullname`, `email`, `phone`, `guest`, `date2`, `time2`, `pay`, `cmt`, `status`) VALUES
(13, 1, 'Ujjwal Soni', 'uj@gmail.com', '9001996520', '1', '06/25/2018', '10:00', 'Paypal', '', 'Cancelled'),
(12, 1, 'Ujjwal Soni', 'uj@gmail.com', '9001996520', '1', '06/20/2018', '10:00', 'Paypal', 'good', 'Cancelled'),
(11, 1, 'Ujjwal Soni', 'uj@gmail.com', '9001996520', 'If more then specify in comments', '06/20/2018', '10:00', 'Paypal', '23', 'Cancelled'),
(14, 1, 'Roopak Rottela', 'uj@gmail.com', '9414937533', '7', '06/26/2018', '19:00', 'Credit/Debit Card', 'wow', 'Confirmed'),
(15, 1, 'Roopak Rottela', 'uj@gmail.com', '9414937533', '7', '06/26/2018', '19:00', 'Credit card', 'badiya', 'Confirmed'),
(16, 1, 'Ujjwal Soni', 'uj@gmail.com', '9001996520', '1', '06/28/2018', '10:00', 'Credit/Debit Card', '', 'Confirmed'),
(17, 1, 'Ujjwal Soni', 'uj@gmail.com', '9001996520', '1', '06/28/2018', '10:00', 'Credit/Debit Card', '', 'Cancelled'),
(18, 1, 'Ujjwal Soni', 'uj@gmail.com', '9001996520', '1', '06/29/2018', '10:00', 'Credit/Debit Card', '', 'Cancelled'),
(19, 1, 'Ujjwal Soni', 'uj@gmail.com', '9001996520', '1', '06/29/2018', '10:00', 'Credit/Debit Card', '', 'Cancelled'),
(20, 1, 'Ujjwal Soni', 'uj@gmail.com', '9001996520', '1', '06/29/2018', '10:00', 'Credit/Debit Card', '', 'Cancelled');

-- --------------------------------------------------------

--
-- Table structure for table `breakfast`
--

CREATE TABLE `breakfast` (
  `id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `quantity` varchar(255) NOT NULL,
  `cost` int(255) NOT NULL,
  `images` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `breakfast`
--

INSERT INTO `breakfast` (`id`, `name`, `quantity`, `cost`, `images`) VALUES
(27, 'Aaloo Sandwich', '1 Piece', 30, 'omelete.jpg'),
(24, 'Poha', '1 Plate', 20, 'poha.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `card`
--

CREATE TABLE `card` (
  `id` int(11) NOT NULL,
  `cust_id` int(11) NOT NULL,
  `card` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `card`
--

INSERT INTO `card` (`id`, `cust_id`, `card`) VALUES
(12, 1, '4567456745674567'),
(9, 1, '9876987698769876');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `category` varchar(30) NOT NULL,
  `item_id` int(11) NOT NULL,
  `cust_id` int(11) NOT NULL,
  `quant` varchar(30) NOT NULL,
  `rs` varchar(30) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `category`, `item_id`, `cust_id`, `quant`, `rs`) VALUES
(150, 'breakfast', 24, 5, '1', '20');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `id` int(11) NOT NULL,
  `firstname` varchar(30) NOT NULL,
  `lastname` varchar(30) NOT NULL,
  `email` varchar(50) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(50) NOT NULL,
  `profileimg` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`id`, `firstname`, `lastname`, `email`, `username`, `password`, `profileimg`) VALUES
(1, 'Ujjwal ', 'Soni', 'uj@gmail.com', 'uj', '12', 'B612_20170226_122233.jpg'),
(5, 'hg', 'gh', 'hg@gmail.com', 'sanju', '123', 'omelete.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `msg`
--

CREATE TABLE `msg` (
  `id` int(11) NOT NULL,
  `custid` varchar(30) NOT NULL,
  `name` varchar(30) NOT NULL,
  `email` varchar(50) NOT NULL,
  `msg` varchar(255) NOT NULL,
  `phone` varchar(30) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `msg`
--

INSERT INTO `msg` (`id`, `custid`, `name`, `email`, `msg`, `phone`) VALUES
(5, '1', 'Ujjwal Soni', 'ujjwal.soni494@gmail.com', 'Your food is fantastic. Keep it up.', '9001996520');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(255) NOT NULL,
  `custid` int(11) NOT NULL,
  `item_name` varchar(255) NOT NULL,
  `quantity` varchar(50) NOT NULL,
  `quantity2` varchar(30) NOT NULL,
  `img` varchar(255) NOT NULL,
  `cost` varchar(50) NOT NULL,
  `receiver` varchar(30) NOT NULL,
  `phone` varchar(11) NOT NULL,
  `address` varchar(255) NOT NULL,
  `address2` varchar(255) NOT NULL,
  `city` varchar(30) NOT NULL,
  `zipcode` int(11) NOT NULL,
  `pay` varchar(40) NOT NULL,
  `date1` date NOT NULL,
  `status` enum('Pending','Delivered') CHARACTER SET latin1 COLLATE latin1_danish_ci NOT NULL,
  `card` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `custid`, `item_name`, `quantity`, `quantity2`, `img`, `cost`, `receiver`, `phone`, `address`, `address2`, `city`, `zipcode`, `pay`, `date1`, `status`, `card`) VALUES
(92, 1, 'Poha', '1 Plate', '1', 'poha.jpg', '20', 'Ujjwal Soni', '9001996520', 'H Number 205 FCI road', 'Opposite natraj talkies', 'Chennai', 324002, 'Credit/Debit Card', '2018-06-29', 'Pending', '4567456745674567'),
(91, 1, 'Aaloo Sandwich', '1 Piece', '3', 'omelete.jpg', '90', 'Ujjwal Soni', '9001996520', 'H Number 205 FCI road', 'Opposite natraj talkies', 'Chennai', 324002, 'Credit/Debit Card', '2018-06-28', 'Pending', '4567456745674567');

-- --------------------------------------------------------

--
-- Table structure for table `roti`
--

CREATE TABLE `roti` (
  `id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `quantity` varchar(255) NOT NULL,
  `cost` int(255) NOT NULL,
  `images` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `roti`
--

INSERT INTO `roti` (`id`, `name`, `quantity`, `cost`, `images`) VALUES
(3, 'Butter roti', '1', 10, 'omelete.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `sabzi`
--

CREATE TABLE `sabzi` (
  `id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `quantity` varchar(255) NOT NULL,
  `cost` int(255) NOT NULL,
  `images` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sabzi`
--

INSERT INTO `sabzi` (`id`, `name`, `quantity`, `cost`, `images`) VALUES
(7, 'Daal Makhni', '1 Bowl', 30, 'omelete.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(255) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `firstname`, `lastname`, `username`, `password`) VALUES
(7, 'Nemo', 'Vj', 'n', '12'),
(12, 'h', 'hg', 'shubham9', '123'),
(11, 'vishu', 'Soni', 'john', '123');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `address`
--
ALTER TABLE `address`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `booktable`
--
ALTER TABLE `booktable`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `breakfast`
--
ALTER TABLE `breakfast`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `card`
--
ALTER TABLE `card`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `msg`
--
ALTER TABLE `msg`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `roti`
--
ALTER TABLE `roti`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sabzi`
--
ALTER TABLE `sabzi`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `address`
--
ALTER TABLE `address`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `booktable`
--
ALTER TABLE `booktable`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
--
-- AUTO_INCREMENT for table `breakfast`
--
ALTER TABLE `breakfast`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;
--
-- AUTO_INCREMENT for table `card`
--
ALTER TABLE `card`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=151;
--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `msg`
--
ALTER TABLE `msg`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=93;
--
-- AUTO_INCREMENT for table `roti`
--
ALTER TABLE `roti`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `sabzi`
--
ALTER TABLE `sabzi`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
