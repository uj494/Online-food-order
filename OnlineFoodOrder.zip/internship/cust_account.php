<?php
session_start();
error_reporting(0);
require_once("modal/custmodel.php");
if(!isset($_SESSION['id'])){
    header("location: index.php");
}
if(isset($_SESSION['page'])){
    unset($_SESSION['page']);
}
?>
<!DOCTYPE html>
<html>
<head>
<title>My Hotel</title>
<link href="web/css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="web/js/jquery.min.js"></script>
<!-- Custom Theme files -->
<!--theme-style-->
<link href="web/css/style.css" rel="stylesheet" type="text/css" media="all" />	
<!--//theme-style-->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Cookery Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!---->
<link href='//fonts.googleapis.com/css?family=Raleway:400,200,100,300,500,600,700,800,900' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Open+Sans+Condensed:300,300italic,700' rel='stylesheet' type='text/css'>
<!-- start-smoth-scrolling -->
		<script type="text/javascript" src="web/js/move-top.js"></script>
		<script type="text/javascript" src="web/js/easing.js"></script>
		<script type="text/javascript">
			jQuery(document).ready(function($) {
				$(".scroll").click(function(event){		
					event.preventDefault();
					$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
				});
			});
		</script>
		<!-- <script
        src="http://code.jquery.com/jquery-3.3.1.slim.js"
        integrity="sha256-fNXJFIlca05BIO2Y5zh1xrShK3ME+/lYZ0j+ChxX2DA="
        crossorigin="anonymous"></script> -->
	<!-- start-smoth-scrolling -->
<link href="web/css/styles.css" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="web/css/component.css" />
	<!-- animation-effect -->
<link href="web/css/animate.min.css" rel="stylesheet"> 
<script src="web/js/wow.min.js"></script>
<script>
 new WOW().init();
</script>
<script src="web/js/sweetalert-dev.js"></script>
  <link rel="stylesheet" href="web/css/sweetalert.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style type="text/css">
	hr.style13 {
	height: 10px;
	width: 710px;
	border: 0;
	box-shadow: 0 10px 10px -10px #8c8b8b inset;
}

.bigicon {
    font-size: 35px;
    color: #36A0FF;
}
</style>
</head>
<body>
<div class="header head">
	<div class="container">
		<div class="logo animated wow pulse" data-wow-duration="1000ms" data-wow-delay="500ms">
			<h1><a href="index.php"><span>My Hotel</span></a></h1>
		</div>
        <div style="color: white; margin-left: 1000px; margin-top: 10px;">
        <?php
            $obj = new custmodel(); 
            $id = $_SESSION['id'];

            $row = $obj->fetch_userById($id);
            if(empty($row->profileimg)){
                 $src = "uploads/default.jpg";
             } else{
                 $src = "uploads/".$row->profileimg;
             }
        ?>
        <a href="cust_account.php"><img class='img-circle'style='height:50px; width:50px;' src='<?= $src ?>'/></a>
        
    </div>
		<div class="nav-icon" style="margin-top: -35px;">		
			<a href="#" class="navicon"></a>
				<div class="toggle">
					<ul class="toggle-menu">
						<li><a  href="cust_index.php">Home</a></li>
						<li><a  href="cust_menu.php">Menu</a></li>
						<li><a  href="cust_cart.php">Cart</a></li>
                        <li><a  href="table.php">Book your table</a></li>
                        <li><a  href="cust_table.php">Your bookings</a></li>
                        <li><a  href="your_orders.php">Orders</a></li>
                        <li><a  href="contact.php">Contact</a></li>
                        <li><a  class="active" href="cust_account.php">Your Account</a></li>
                        <li><a  href="cust_logout.php">Logout</a></li>
					</ul>
				</div>
			<script>
			$('.navicon').on('click', function (e) {
			  e.preventDefault();
			  $(this).toggleClass('navicon--active');
			  $('.toggle').toggleClass('toggle--active');
			});
			</script>
		</div>
	<div class="clearfix"></div>
	</div>
	<!-- start search-->	
		
</div>

<?php
    $obj = new custmodel(); 
    $id = $_SESSION['id'];

    $row = $obj->fetch_userById($id);

 

    if(!empty($_REQUEST['pass'])){  

?>

        <div align="center" class="alert alert-success"   id="msg">
            <i class="fa fa-check-circle" style="font-size:48px;"></i><h3><strong>Your password has been changed successfully!</strong></h3>
        </div>
<?php } 

    if(!empty($_REQUEST['pro'])){

?>
        <div align="center" class="alert alert-success"   id="msg">
            <i class="fa fa-check-circle" style="font-size:48px;"></i><h3><strong>Your profile has been updated successfully!</strong></h3>
        </div>
     <?php } ?>   
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="well well-sm">
                <h1 class="text-center">Profile</h1><br>
                 <div align="center">
                        <?php
                          if(empty($row->profileimg)){
                                $src = "uploads/default.jpg";
                            } else{
                                $src = "uploads/".$row->profileimg;
                            }
                        ?>
                        <img class='img-circle' id="img1" style='height:200px; width:200px;' src='<?= $src ?>'/>
                            
                        </div>
                        <br>

                 <form class="form-horizontal" method="post" action="updatecust_account.php" enctype="multipart/form-data">
                    
                        <div align="center">
                            
                          
                                <input style="display:none" name="img" type="file" id="fileupload1" />
                                <input type="button" class="btn btn-primary" id="btnUpload" onclick='$("#fileupload1").click()' value="Upload"/>
                                &nbsp;&nbsp;<input type="submit" name="profileimg" class="btn btn-primary" value="Submit"/>
                        </div>
                        <br>       
                    </form> 
                <form class="form-horizontal" method="post" action="updatecust_account.php">
                    
                    <fieldset>
                        <div class="form-group">
                        	
                            <span class="col-md-1 col-md-offset-2 text-center"><i class="fa fa-user bigicon" style="color: blue;"></i></span>

                            <div class="col-md-8">
                            	<label>Firstname:</label>
                                <input id="fname" name="fname" type="text" placeholder="<?=$row->firstname?>" value="<?=$row->firstname?>" class="form-control">
                            </div>
                        </div>
                        <div class="form-group">
                            <span class="col-md-1 col-md-offset-2 text-center"><i class="fa fa-user bigicon" style="color: blue;"></i></span>
                            <div class="col-md-8">
                            	<label>Laststname:</label>
                                <input id="lname" name="lname" type="text" placeholder="<?=$row->lastname?>" value="<?=$row->lastname?>" class="form-control">
                            </div>
                        </div>
                        <div class="form-group">
                            <span class="col-md-1 col-md-offset-2 text-center"><i class="fa fa-envelope fa-2x" style="color:blue;"></i></i></span>
                            <div class="col-md-8">
                                <label>E-mail:</label>
                                <input id="ename" name="ename" type="email" placeholder="<?=$row->email?>" value="<?=$row->email?>" class="form-control">
                            </div>
                        </div>
						<div class="form-group">
                            <div class="col-md-12 text-center">
                                <button type="submit" name="profile" class="btn btn-primary btn-lg">Submit</button>
                            </div>
                        </div>
                    </fieldset>
                </form><br>
                <hr class="style13" style="margin-left: 300px; margin-right: 300px;">
                <form class="form-horizontal" method="post" action="">
                    <fieldset>
                        <h1 class="text-center">Change Password:</h1><br>

                        <div class="form-group">
                        	
                            <span class="col-md-1 col-md-offset-2 text-center"><i class="fa fa-lock bigicon"style="color: blue;"></i></span>

                            <div class="col-md-8">
                            	<label class="">Current Password: </label>
    							<input id="curp" class="form-control" type="Password" required name="currentpass" onkeyup='check();'><br>
   							 	<input type="hidden" name="actualpass" id="actual" onkeyup='check();' value=<?=$row->password?> >
                            </div>
                        </div>
                        <div class="form-group">
                            <span class="col-md-1 col-md-offset-2 text-center"><i class="fa fa-lock bigicon" style="color: blue;"></i></span>
                            <div class="col-md-8">
                            	<label class="">New Password:</label>
   								<input class="form-control" type="Password" name="password" required id="password"  onkeyup='check();'><br>
                            </div>
                        </div>
                        <div class="form-group">
                            <span class="col-md-1 col-md-offset-2 text-center"><i class="fa fa-lock bigicon" style="color: blue;"></i></span>
                            <div class="col-md-8">
                            	<label class="">Confirm Password:</label>
    							<input class="form-control" type="Password" name="confirm_password" required id="confirm_password"  onkeyup='check();'><br>
     							<span id='message'></span>
     			
                            </div>
                        </div>
						<div class="form-group">
                            <div class="col-md-12 text-center">
                                <button type="button" name="subpass" value="update" id="b" class="btn btn-primary btn-lg">Update Password</button>
                            </div>
                        </div>
                    </fieldset>
                </form>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
    function JSalert(msg){
    swal({   title: msg,   
    
    type: "warning",   
    showCancelButton: false,   
    confirmButtonColor: "#FF0000",   
    confirmButtonText: "Ok",   
    cancelButtonText: "No!",   
    closeOnConfirm: true,   
    closeOnCancel: true }, 
    function(isConfirm){   
        if (isConfirm) 
    {   
        swal("Account Removed!", "Your account is removed permanently!", "success");
        } 
         });
}
</script>

<script type="text/javascript">
  var check = function() {
  	var current=document.getElementById( "curp" ).value;
  	var actual=document.getElementById( "actual" ).value;
  	var newpass=document.getElementById("password").value;
  	var confpass=document.getElementById("confirm_password").value;
  	if(current == actual){
  if (document.getElementById('password').value ==
    document.getElementById('confirm_password').value) {
    document.getElementById('message').style.color = 'green';
    document.getElementById('message').innerHTML = 'matching';
  } else {
    document.getElementById('message').style.color = 'red';
    document.getElementById('message').innerHTML = 'not matching';
  }
} else {
	document.getElementById('message').style.color = 'red';
    document.getElementById('message').innerHTML = 'invalid current password';
}
}



$(function(){

     function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $('#img1').attr('src', e.target.result);
            }

            reader.readAsDataURL(input.files[0]);
        }
    }

    $("#fileupload1").on("change", function() {
        readURL(this);
       //alert($(this).val());
        //$("#img1").attr("src",$(this).val());
        //$("#formimg").submit();
    });

	$('#b').click(function(){
        //alert("hello");
		var newpass = $("#password").val();
		var actual = $("#actual").val();
		var current = $("#curp").val();
		var confpass = $("#confirm_password").val();
		var button = $("#b").val();
		//alert("updatecust_account.php?new="+newpass+"&act="+actual+"&crr="+current+"&conf="+confpass+"&button="+button);
        $.post("updatecust_account.php?new="+newpass+"&act="+actual+"&crr="+current+"&conf="+confpass+"&button="+button,function(data){
            //alert(data);
            if(data == "updated"){
                //alert("called");
                window.location.href = 'cust_account.php?pass=changed';
            }
            if (data == "invalid") {
                JSalert("Invalid current password!");
            }
            if (data == "notmatch") {
                JSalert("Passwords don't match!");
            }
        });
	});
});

</script>

<!--footer-->
    <div class="footer">
        <div class="container">
            <div class="footer-head">
                <div class="col-md-8 footer-top animated wow fadeInRight" data-wow-duration="1000ms" data-wow-delay="500ms">
                    <ul class=" in">
                        <li><a  href="cust_index.php">Home</a></li>
                        <li><a  href="cust_menu.php">Menu</a></li>
                        <li><a  href="cust_cart.php">Cart</a></li>
                        <li><a  href="table.php">Book your table</a></li>
                        <li><a  href="cust_table.php">Your bookings</a></li>
                        <li><a  href="your_orders.php">Orders</a></li>
                        <li><a  href="contact.php">Contact</a></li>
                        <li><a  class="active" href="cust_account.php">Your Account</a></li>
                        <li><a  href="cust_logout.php">Logout</a></li>
                    </ul>                   
                        <span>There are many variations of passages</span>
                </div>
                <div class="col-md-4 footer-bottom  animated wow fadeInLeft" data-wow-duration="1000ms" data-wow-delay="500ms">
                    <h2>Follow Us</h2>
                    <label><i class="glyphicon glyphicon-menu-up"></i></label>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis.</p>
                    <ul class="social-ic">
                        <li><a href="#"><i></i></a></li>
                        <li><a href="#"><i class="ic"></i></a></li>
                        <li><a href="#"><i class="ic1"></i></a></li>
                        <li><a href="#"><i class="ic2"></i></a></li>
                        <li><a href="#"><i class="ic3"></i></a></li>
                    </ul>

                </div>
            <div class="clearfix"> </div>
                    
            
    </div>      
    <!--//footer-->