<!DOCTYPE html>
<html>
<head>
	<title>My Hotel</title>
	<script
        src="http://code.jquery.com/jquery-3.3.1.slim.js"
        integrity="sha256-fNXJFIlca05BIO2Y5zh1xrShK3ME+/lYZ0j+ChxX2DA="
        crossorigin="anonymous"></script>
</head>
<body>

</body>
</html>

<?php
session_start();
error_reporting(0);
require_once("modal/menumodel.php");
echo "<link rel='stylesheet' type='text/css' href='style.css'>";

		$obj = new menumodel();
		$id = $_SESSION['id'];

		if (isset($_POST['submit'])) {

			$target = "uploads/".basename($_FILES['file']['name']);

			$category = $_POST['cat'];
			$item = $_POST['iname'];
			$quantity = $_POST['quant'];
			$cost = $_POST['cost'];

			$image = $_FILES['file']['name'];
			
			$msg = "";
						
						$obj->insert_menu($category, $item, $quantity, $cost, $image);

						if(move_uploaded_file($_FILES['file']['tmp_name'], $target)){
							$msg = "done";
						} else {
							$msg = "problem"; 
						}
						
						header('Location: addfood.php?add=success');

				
		}
	