<?php
session_start();
error_reporting(0);
if(!isset($_SESSION['id'])){
	header("location: index.php");
}
require_once("modal/menumodel.php");
?>

<!DOCTYPE html>
<html>
<head>
<title>My Hotel</title>
<link href="web/css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="web/js/jquery.min.js"></script>
<!-- Custom Theme files -->
<!--theme-style-->
<link href="web/css/style.css" rel="stylesheet" type="text/css" media="all" />	
<!--//theme-style-->
<!-- <META http-equiv="refresh" content="60;URL=addfood.php"> -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Cookery Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!---->
<link href='//fonts.googleapis.com/css?family=Raleway:400,200,100,300,500,600,700,800,900' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Open+Sans+Condensed:300,300italic,700' rel='stylesheet' type='text/css'>
<!-- start-smoth-scrolling -->
		<script type="text/javascript" src="web/js/move-top.js"></script>
		<script type="text/javascript" src="web/js/easing.js"></script>
		<script type="text/javascript">
			jQuery(document).ready(function($) {
				$(".scroll").click(function(event){		
					event.preventDefault();
					$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
				});
			});
		</script>
	<!-- start-smoth-scrolling -->
<link href="web/css/styles.css" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="web/css/component.css" />
	<!-- animation-effect -->
<link href="web/css/animate.min.css" rel="stylesheet"> 
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<script src="web/js/wow.min.js"></script>
<script>
 new WOW().init();
</script>
<!-- //animation-effect -->

</head>
<body>
<div class="header head">
	<div class="container">
		<div class="logo animated wow pulse" data-wow-duration="1000ms" data-wow-delay="500ms">
			<h1><a href="index.html"><span>My Hotel</span></a></h1>
		</div>
		<div class="nav-icon">		
			<a href="#" class="navicon"></a>
				<div class="toggle">
					<ul class="toggle-menu">
						<li><a  href="admin_index.php">Home</a></li>
						<li><a  href="admin_menu.php">Menu</a></li>
						<li><a  class="active" href="addfood.php">Add Items</a></li>
						<li><a  href="admin_orders.php">All orders</a></li>
						<li><a  href="bookings.php">All bookings</a></li>
						<li><a  href="cust_msg.php">Customer messages</a></li>
						<li><a  href="useraccount.php">Your Account</a></li>
						<li><a  href="logout.php">Logout</a></li>
					</ul>
				</div>
			<script>
			$('.navicon').on('click', function (e) {
			  e.preventDefault();
			  $(this).toggleClass('navicon--active');
			  $('.toggle').toggleClass('toggle--active');
			});
			</script>
		</div>
	<div class="clearfix"></div>
	</div>
	<!-- start search-->	
		
</div>
<!--content-->
<?php
		if(!empty($_REQUEST['add'])){	
			
	?>
<div align="center" class="alert alert-success"   id="msg">
  <i class="fa fa-check-circle" style="font-size:48px; margin-bottom: 3px; margin-top: -10px;"></i><h3><strong>Item added successfully in the Menu! <a href="admin_menu.php">Go to Menu.</a></strong></h3>
</div><br><br>
<?php } ?>
<!-- <div id="demo"></div><br>
<div id="p"></div>
<script type="text/javascript">
    var d = new Date();
    var pretty = [
  d.getHours(),
  ':',
  d.getMinutes()
].join('');
    document.getElementById("demo").innerHTML = pretty;
    if (pretty == "13:45") {
    	document.getElementById("demo").innerHTML = "hi there";
    }
</script> -->

<h2 align="center">Add Item</h2><br>
<div class="form-group container">
	<form action="add-inc.php" method="post" enctype="multipart/form-data">
		<div >
		<label>Category</label>
		<select class="form-control" name="cat">
    <option>Breakfast</option>
    <option>sabzi</option>
    <option>Roti</option>
  </select>
  	</div><br>
  	<div >
		<label>Item name</label>
		<input type="text" class="form-control" name="iname"><br>
	</div>
	<div >
		<label>Quantity</label>
		<input type="text" class="form-control" name="quant"><br>
		</div>
		<div >
		<label>Cost</label>
		<input type="text" class="form-control" name="cost"><br>
	</div>
	<div >
		<label>Image</label>
		<input type="file" class="form-control" name="file"><br>
	</div>
	<div align="center">
	<input type="submit" name="submit" id="submit" value="Add" class="btn btn-primary btn-lg">
	</div>
	</form>
</div>

<div class="footer">
		<div class="container">
			<div class="footer-head">
				<div class="col-md-8 footer-top animated wow fadeInRight" data-wow-duration="1000ms" data-wow-delay="500ms">
					<ul class=" in">
						<li><a class="active" href="admin_index.php">Home</a></li>
						<li><a  href="admin_menu.php">Menu</a></li>
						<li><a  href="addfood.php">Add Items</a></li>
						<li><a  href="admin_orders.php">All orders</a></li>
						<li><a  href="bookings.php">All bookings</a></li>
						<li><a  href="cust_msg.php">Customer messages</a></li>
						<li><a  href="useraccount.php">Your Account</a></li>
						<li><a  href="logout.php">Logout</a></li>
					</ul>					
						<span>There are many variations of passages</span>
				</div>
				<div class="col-md-4 footer-bottom  animated wow fadeInLeft" data-wow-duration="1000ms" data-wow-delay="500ms">
					<h2>Follow Us</h2>
					<label><i class="glyphicon glyphicon-menu-up"></i></label>
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis.</p>
					<ul class="social-ic">
						<li><a href="#"><i></i></a></li>
						<li><a href="#"><i class="ic"></i></a></li>
						<li><a href="#"><i class="ic1"></i></a></li>
						<li><a href="#"><i class="ic2"></i></a></li>
						<li><a href="#"><i class="ic3"></i></a></li>
					</ul>

				</div>
			<div class="clearfix"> </div>
					
			
	</div>		
	<!--//footer-->
</body>
</html>