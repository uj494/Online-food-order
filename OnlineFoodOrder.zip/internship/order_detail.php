<?php
session_start();
error_reporting(0);
if(!isset($_SESSION['id'])){
	header("location: index.php");
}
if(isset($_SESSION['page'])){
    header("location: cust_index.php");
}
require_once("modal/menumodel.php");
require_once("modal/ordermodel.php");
$obj = new menumodel();
$objorder = new ordermodel();
?>
<!DOCTYPE html>
<html>
<head>
<title>My Hotel</title>
<link href="web/css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="web/js/jquery.min.js"></script>
<!-- Custom Theme files -->
<!--theme-style-->
<link href="web/css/style.css" rel="stylesheet" type="text/css" media="all" />	
<!--//theme-style-->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Cookery Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!---->
<link href='//fonts.googleapis.com/css?family=Raleway:400,200,100,300,500,600,700,800,900' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Open+Sans+Condensed:300,300italic,700' rel='stylesheet' type='text/css'>
<!-- start-smoth-scrolling -->
		<script type="text/javascript" src="web/js/move-top.js"></script>
		<script type="text/javascript" src="web/js/easing.js"></script>
		<script type="text/javascript">
			jQuery(document).ready(function($) {
				$(".scroll").click(function(event){		
					event.preventDefault();
					$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
				});
			});
		</script>
	<!-- start-smoth-scrolling -->
<link href="web/css/styles.css" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="web/css/component.css" />
	<!-- animation-effect -->
<link href="web/css/animate.min.css" rel="stylesheet"> 
<script src="web/js/wow.min.js"></script>
<script>
 new WOW().init();
</script>
<!-- //animation-effect -->
<script type="text/javascript">
    $(function(){
    $('.del').click(function(){
        //e.preventDefault();
        var id = $(this).attr("id");
        var sta = $("#dis"+id).attr("id");
        $.post("delcard.php?idadd="+id,function(data){
                //alert(data);
                jQuery("#dis"+id).hide();
            });
    });
});
</script>
<style type="text/css">
	/* Add a slash symbol (/) before/behind each list item */
ul.breadcrumb li+li:before {
    padding: 8px;
    color: black;
    content: "/\00a0";
}
</style>

</head>
<body>
<div class="header head">
	<div class="container">
		<div class="logo animated wow pulse" data-wow-duration="1000ms" data-wow-delay="500ms">
			<h1><a href="index.php"><span>My Hotel</span></a></h1>
		</div>
		<div class="nav-icon">		
			<a href="#" class="navicon"></a>
				<div class="toggle">
					<ul class="toggle-menu">
						<li><a  href="cust_index.php">Home</a></li>
						<li><a class="active" href="cust_menu.php">Menu</a></li>
						<li><a  href="cust_cart.php">Cart</a></li>
						<li><a  href="your_orders.php">Orders</a></li>
						<li><a  href="contact.html">Contact</a></li>
						<li><a  href="useraccount.php">Your Account</a></li>
						<li><a  href="cust_logout.php">Logout</a></li>
					</ul>
				</div>
			<script>
			$('.navicon').on('click', function (e) {
			  e.preventDefault();
			  $(this).toggleClass('navicon--active');
			  $('.toggle').toggleClass('toggle--active');
			});
			</script>
		</div>
	<div class="clearfix"></div>
	</div>
</div><br><br>
<h3><strong><ul class="breadcrumb" style="margin-top: -30px;float: left;">
  <li>Cart</li>
  <li style="color: red;">Order Details</li>
  <li>Payment</li>
</ul></strong></h3> <br><br>
<!--code-->
<?php
$id = $_SESSION['id'];
$add = $objorder->fetch_alladd($id);
foreach ($add as $key) {?>
	<div id="dis<?=$key->id?>">
		<div class="col-md-4 menu-bottom1">
			<div class='well' style='border-color: blue; width: 250px;'>
				<h3><strong><?php echo $key->receiver?></strong></h3><br>
				<p><?php echo $key->add1?>,</p>
				<p><?php echo $key->add2?>.</p>
				<p><?php echo $key->city?></p>
				<p><?php echo $key->state?></p>
				<p><?php echo $key->zipcode?></p>
				<p><?php echo $key->phone?></p><br>
				<a class="btn btn-primary" href="order-pay.php?id_add=<?=$key->id?>">Use this address</a>&nbsp;&nbsp;&nbsp;<a class="del btn btn-primary" id="<?=$key->id?>">Delete</a>
			</div>
		</div>
	</div>

<?php }
?>
<div class="clearfix"></div>
<h2 align="center"><strong>Enter your details</strong></h2>
<div style="padding: 40px;">
<form method="POST" action="order-pay.php?id_add">

	<div class="form-group"> <!-- Full Name -->
		<label for="full_name_id" class="control-label">Full Name</label>
		<input type="text" class="form-control" id="full_name_id" name="full_name" placeholder="For example: John Deer">
	</div>	

	<div class="form-group"> <!-- Street 1 -->
		<label for="street1_id" class="control-label">Street Address 1</label>
		<input type="text" class="form-control" id="street1_id" name="street1" placeholder="Street address, P.O. box, company name, c/o">
	</div>					
							
	<div class="form-group"> <!-- Street 2 -->
		<label for="street2_id" class="control-label">Street Address 2</label>
		<input type="text" class="form-control" id="street2_id" name="street2" placeholder="Apartment, suite, unit, building, floor, etc.">
	</div>	

	<div class="form-group"> <!-- City-->
		<label for="city_id" class="control-label">City</label>
		<select class="form-control" id="city_id" name="city" placeholder="Smallville">
			<option>Delhi</option>
			<option>Mumbai</option>
			<option>Chennai</option>
			<option>Banglore</option>
			<option>Chandigarh</option>
			<option>Jaipur</option>
			<option>Kolkata</option>
		</select>			
	</div>									
				
	
	<div class="form-group"> <!-- Full Name -->
		<label for="phone" class="control-label">Phone</label>
		<input type="text" class="form-control" id="phone" name="phone" placeholder="Phome Number" pattern= "[0-9]{10}">
	</div>	

	<div class="form-group"> <!-- Zip Code-->
		<label for="zip_id" class="control-label">Zip Code</label>
		<input type="text" class="form-control" id="zip_id" name="zip" placeholder="#####" pattern= "[0-9]{6}">
	</div><br>
	<input type="checkbox" name="save">&nbsp;Save this address for faster checkout.

	<br><br>
	<div class="form-group"> <!-- Submit Button -->
		<button type="submit" class="btn btn-primary">Proceed to pay!</button>
		&nbsp;&nbsp;<a href="cust_cart.php" class="btn btn-primary">Back to cart</a>
	</div><br><br>
	

	
</form>				
</div>
<br><br>

<!--footer-->
	<div class="footer">
		<div class="container">
			<div class="footer-head">
				<div class="col-md-8 footer-top animated wow fadeInRight" data-wow-duration="1000ms" data-wow-delay="500ms">
					<ul class=" in">
						<li><a  href="cust_index.php">Home</a></li>
						<li><a  href="cust_menu.php">Menu</a></li>
						<li><a  href="cust_cart.php">Cart</a></li>
                        <li><a  href="table.php">Book your table</a></li>
                        <li><a  href="cust_table.php">Your bookings</a></li>
                        <li><a  href="your_orders.php">Orders</a></li>
                        <li><a  href="contact.php">Contact</a></li>
                        <li><a  class="active" href="cust_account.php">Your Account</a></li>
                        <li><a  href="cust_logout.php">Logout</a></li>
					</ul>					
						<span>There are many variations of passages</span>
				</div>
				<div class="col-md-4 footer-bottom  animated wow fadeInLeft" data-wow-duration="1000ms" data-wow-delay="500ms">
					<h2>Follow Us</h2>
					<label><i class="glyphicon glyphicon-menu-up"></i></label>
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis.</p>
					<ul class="social-ic">
						<li><a href="#"><i></i></a></li>
						<li><a href="#"><i class="ic"></i></a></li>
						<li><a href="#"><i class="ic1"></i></a></li>
						<li><a href="#"><i class="ic2"></i></a></li>
						<li><a href="#"><i class="ic3"></i></a></li>
					</ul>

				</div>
			<div class="clearfix"> </div>
					
			
	</div>		
	<!--//footer-->